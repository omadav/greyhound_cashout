﻿Public Class RatingForm

 
    Public Sub New(ByVal question As String, ByVal anchor1 As String, ByVal anchor2 As String, Optional ByVal col As Integer = 0)

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        Me.Label1.Text = anchor1
        Me.Label2.Text = anchor2
        Me.Label3.Text = question
        If col > 0 Then Me.ProgressBar1.ForeColor = Color.FromArgb(col)
        Me.ProgressBar1.Value = 0
        Me.Button1.Visible = False
    End Sub
    Private Sub ProgressBar1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ProgressBar1.MouseDown
        Me.ProgressBar1.Value = 100 * (e.X / Me.ProgressBar1.Width)
        Me.Button1.Visible = True
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Hide()
    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click

    End Sub
End Class