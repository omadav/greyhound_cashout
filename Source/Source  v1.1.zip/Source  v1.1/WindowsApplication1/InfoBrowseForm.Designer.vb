﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class InfoBrowseForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(InfoBrowseForm))
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.ChooseCDog = New System.Windows.Forms.CheckBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.TabControl2 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.label200 = New System.Windows.Forms.Label
        Me.CountyDogPanel = New System.Windows.Forms.Label
        Me.WinDogPanel = New System.Windows.Forms.Label
        Me.FormDogPanel = New System.Windows.Forms.Label
        Me.ChooseADog = New System.Windows.Forms.CheckBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.AgeDogPanel = New System.Windows.Forms.Label
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.ChooseBDog = New System.Windows.Forms.CheckBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.TabPage4 = New System.Windows.Forms.TabPage
        Me.Label32 = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.Label34 = New System.Windows.Forms.Label
        Me.Label35 = New System.Windows.Forms.Label
        Me.Label36 = New System.Windows.Forms.Label
        Me.Label37 = New System.Windows.Forms.Label
        Me.ChooseDDog = New System.Windows.Forms.CheckBox
        Me.Label38 = New System.Windows.Forms.Label
        Me.Label39 = New System.Windows.Forms.Label
        Me.Label40 = New System.Windows.Forms.Label
        Me.Label41 = New System.Windows.Forms.Label
        Me.Label42 = New System.Windows.Forms.Label
        Me.Label43 = New System.Windows.Forms.Label
        Me.TabPage5 = New System.Windows.Forms.TabPage
        Me.Label44 = New System.Windows.Forms.Label
        Me.Label45 = New System.Windows.Forms.Label
        Me.Label46 = New System.Windows.Forms.Label
        Me.Label47 = New System.Windows.Forms.Label
        Me.Label48 = New System.Windows.Forms.Label
        Me.Label49 = New System.Windows.Forms.Label
        Me.ChooseEDog = New System.Windows.Forms.CheckBox
        Me.Label50 = New System.Windows.Forms.Label
        Me.Label51 = New System.Windows.Forms.Label
        Me.Label52 = New System.Windows.Forms.Label
        Me.Label53 = New System.Windows.Forms.Label
        Me.Label54 = New System.Windows.Forms.Label
        Me.Label55 = New System.Windows.Forms.Label
        Me.TabPage6 = New System.Windows.Forms.TabPage
        Me.Label56 = New System.Windows.Forms.Label
        Me.Label57 = New System.Windows.Forms.Label
        Me.Label58 = New System.Windows.Forms.Label
        Me.Label59 = New System.Windows.Forms.Label
        Me.Label60 = New System.Windows.Forms.Label
        Me.Label179 = New System.Windows.Forms.Label
        Me.ChooseFDog = New System.Windows.Forms.CheckBox
        Me.Label180 = New System.Windows.Forms.Label
        Me.Label181 = New System.Windows.Forms.Label
        Me.Label182 = New System.Windows.Forms.Label
        Me.Label183 = New System.Windows.Forms.Label
        Me.Label184 = New System.Windows.Forms.Label
        Me.Label185 = New System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.TabPage11 = New System.Windows.Forms.TabPage
        Me.Label139 = New System.Windows.Forms.Label
        Me.Label140 = New System.Windows.Forms.Label
        Me.Label141 = New System.Windows.Forms.Label
        Me.Label142 = New System.Windows.Forms.Label
        Me.Label143 = New System.Windows.Forms.Label
        Me.Label144 = New System.Windows.Forms.Label
        Me.Label145 = New System.Windows.Forms.Label
        Me.Label146 = New System.Windows.Forms.Label
        Me.ChooseBPos = New System.Windows.Forms.CheckBox
        Me.ChooseCPos = New System.Windows.Forms.CheckBox
        Me.ChooseDPos = New System.Windows.Forms.CheckBox
        Me.ChooseEPos = New System.Windows.Forms.CheckBox
        Me.ChooseFPos = New System.Windows.Forms.CheckBox
        Me.Label147 = New System.Windows.Forms.Label
        Me.Label148 = New System.Windows.Forms.Label
        Me.Label149 = New System.Windows.Forms.Label
        Me.Label150 = New System.Windows.Forms.Label
        Me.ChooseAPos = New System.Windows.Forms.CheckBox
        Me.Label151 = New System.Windows.Forms.Label
        Me.Label152 = New System.Windows.Forms.Label
        Me.Label153 = New System.Windows.Forms.Label
        Me.Label154 = New System.Windows.Forms.Label
        Me.Label155 = New System.Windows.Forms.Label
        Me.Label156 = New System.Windows.Forms.Label
        Me.Label157 = New System.Windows.Forms.Label
        Me.Label158 = New System.Windows.Forms.Label
        Me.TabPage10 = New System.Windows.Forms.TabPage
        Me.Label159 = New System.Windows.Forms.Label
        Me.Label160 = New System.Windows.Forms.Label
        Me.Label161 = New System.Windows.Forms.Label
        Me.Label162 = New System.Windows.Forms.Label
        Me.Label163 = New System.Windows.Forms.Label
        Me.Label164 = New System.Windows.Forms.Label
        Me.Label165 = New System.Windows.Forms.Label
        Me.Label166 = New System.Windows.Forms.Label
        Me.ChooseBWin = New System.Windows.Forms.CheckBox
        Me.ChooseCWin = New System.Windows.Forms.CheckBox
        Me.ChooseDWin = New System.Windows.Forms.CheckBox
        Me.ChooseEWin = New System.Windows.Forms.CheckBox
        Me.ChooseFWin = New System.Windows.Forms.CheckBox
        Me.Label167 = New System.Windows.Forms.Label
        Me.Label168 = New System.Windows.Forms.Label
        Me.Label169 = New System.Windows.Forms.Label
        Me.Label170 = New System.Windows.Forms.Label
        Me.ChooseAWin = New System.Windows.Forms.CheckBox
        Me.Label171 = New System.Windows.Forms.Label
        Me.Label172 = New System.Windows.Forms.Label
        Me.Label173 = New System.Windows.Forms.Label
        Me.Label174 = New System.Windows.Forms.Label
        Me.Label175 = New System.Windows.Forms.Label
        Me.Label176 = New System.Windows.Forms.Label
        Me.Label177 = New System.Windows.Forms.Label
        Me.Label178 = New System.Windows.Forms.Label
        Me.TabPage9 = New System.Windows.Forms.TabPage
        Me.Label79 = New System.Windows.Forms.Label
        Me.Label78 = New System.Windows.Forms.Label
        Me.Label77 = New System.Windows.Forms.Label
        Me.Label76 = New System.Windows.Forms.Label
        Me.Label75 = New System.Windows.Forms.Label
        Me.Label74 = New System.Windows.Forms.Label
        Me.Label73 = New System.Windows.Forms.Label
        Me.ChooseBAge = New System.Windows.Forms.CheckBox
        Me.ChooseCAge = New System.Windows.Forms.CheckBox
        Me.ChooseEAge = New System.Windows.Forms.CheckBox
        Me.ChooseDAge = New System.Windows.Forms.CheckBox
        Me.ChooseFAge = New System.Windows.Forms.CheckBox
        Me.Label71 = New System.Windows.Forms.Label
        Me.Label72 = New System.Windows.Forms.Label
        Me.Label69 = New System.Windows.Forms.Label
        Me.Label70 = New System.Windows.Forms.Label
        Me.ChooseAAge = New System.Windows.Forms.CheckBox
        Me.Label67 = New System.Windows.Forms.Label
        Me.Label68 = New System.Windows.Forms.Label
        Me.Label65 = New System.Windows.Forms.Label
        Me.Label66 = New System.Windows.Forms.Label
        Me.Label63 = New System.Windows.Forms.Label
        Me.Label64 = New System.Windows.Forms.Label
        Me.Label61 = New System.Windows.Forms.Label
        Me.Label62 = New System.Windows.Forms.Label
        Me.TabPage8 = New System.Windows.Forms.TabPage
        Me.Label99 = New System.Windows.Forms.Label
        Me.Label100 = New System.Windows.Forms.Label
        Me.Label101 = New System.Windows.Forms.Label
        Me.Label102 = New System.Windows.Forms.Label
        Me.Label103 = New System.Windows.Forms.Label
        Me.Label104 = New System.Windows.Forms.Label
        Me.Label105 = New System.Windows.Forms.Label
        Me.Label106 = New System.Windows.Forms.Label
        Me.ChooseBForm = New System.Windows.Forms.CheckBox
        Me.ChooseCForm = New System.Windows.Forms.CheckBox
        Me.ChooseDForm = New System.Windows.Forms.CheckBox
        Me.ChooseEform = New System.Windows.Forms.CheckBox
        Me.ChooseFForm = New System.Windows.Forms.CheckBox
        Me.Label107 = New System.Windows.Forms.Label
        Me.Label108 = New System.Windows.Forms.Label
        Me.Label109 = New System.Windows.Forms.Label
        Me.Label110 = New System.Windows.Forms.Label
        Me.ChooseAForm = New System.Windows.Forms.CheckBox
        Me.Label111 = New System.Windows.Forms.Label
        Me.Label112 = New System.Windows.Forms.Label
        Me.Label113 = New System.Windows.Forms.Label
        Me.Label114 = New System.Windows.Forms.Label
        Me.Label115 = New System.Windows.Forms.Label
        Me.Label116 = New System.Windows.Forms.Label
        Me.Label117 = New System.Windows.Forms.Label
        Me.Label138 = New System.Windows.Forms.Label
        Me.TabPage7 = New System.Windows.Forms.TabPage
        Me.Label137 = New System.Windows.Forms.Label
        Me.Label118 = New System.Windows.Forms.Label
        Me.Label119 = New System.Windows.Forms.Label
        Me.Label120 = New System.Windows.Forms.Label
        Me.Label121 = New System.Windows.Forms.Label
        Me.Label122 = New System.Windows.Forms.Label
        Me.Label123 = New System.Windows.Forms.Label
        Me.Label124 = New System.Windows.Forms.Label
        Me.ChooseBCounty = New System.Windows.Forms.CheckBox
        Me.ChooseCCounty = New System.Windows.Forms.CheckBox
        Me.ChooseDCounty = New System.Windows.Forms.CheckBox
        Me.ChooseECounty = New System.Windows.Forms.CheckBox
        Me.ChooseFcounty = New System.Windows.Forms.CheckBox
        Me.Label125 = New System.Windows.Forms.Label
        Me.Label126 = New System.Windows.Forms.Label
        Me.Label127 = New System.Windows.Forms.Label
        Me.Label128 = New System.Windows.Forms.Label
        Me.ChooseACounty = New System.Windows.Forms.CheckBox
        Me.Label129 = New System.Windows.Forms.Label
        Me.Label130 = New System.Windows.Forms.Label
        Me.Label131 = New System.Windows.Forms.Label
        Me.Label132 = New System.Windows.Forms.Label
        Me.Label133 = New System.Windows.Forms.Label
        Me.Label134 = New System.Windows.Forms.Label
        Me.Label135 = New System.Windows.Forms.Label
        Me.Label136 = New System.Windows.Forms.Label
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage3.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TabPage11.SuspendLayout()
        Me.TabPage10.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TabPage3.Controls.Add(Me.Label20)
        Me.TabPage3.Controls.Add(Me.Label21)
        Me.TabPage3.Controls.Add(Me.Label22)
        Me.TabPage3.Controls.Add(Me.Label23)
        Me.TabPage3.Controls.Add(Me.Label24)
        Me.TabPage3.Controls.Add(Me.Label25)
        Me.TabPage3.Controls.Add(Me.ChooseCDog)
        Me.TabPage3.Controls.Add(Me.Label26)
        Me.TabPage3.Controls.Add(Me.Label27)
        Me.TabPage3.Controls.Add(Me.Label28)
        Me.TabPage3.Controls.Add(Me.Label29)
        Me.TabPage3.Controls.Add(Me.Label30)
        Me.TabPage3.Controls.Add(Me.Label31)
        Me.TabPage3.Location = New System.Drawing.Point(4, 40)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(556, 418)
        Me.TabPage3.TabIndex = 1
        Me.TabPage3.Text = "Dog C"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(328, 287)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(148, 39)
        Me.Label20.TabIndex = 38
        Me.Label20.Text = "3 3 2 1 4"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(94, 289)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(219, 31)
        Me.Label21.TabIndex = 37
        Me.Label21.Text = "Average Position"
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(142, 27)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(365, 39)
        Me.Label22.TabIndex = 36
        Me.Label22.Text = "45"
        '
        'Label23
        '
        Me.Label23.AutoEllipsis = True
        Me.Label23.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(142, 79)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(365, 39)
        Me.Label23.TabIndex = 35
        Me.Label23.Text = "45"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(329, 235)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(55, 39)
        Me.Label24.TabIndex = 34
        Me.Label24.Text = "45"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(328, 180)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(148, 39)
        Me.Label25.TabIndex = 33
        Me.Label25.Text = "3 3 2 1 4"
        '
        'ChooseCDog
        '
        Me.ChooseCDog.AutoSize = True
        Me.ChooseCDog.Location = New System.Drawing.Point(197, 356)
        Me.ChooseCDog.Name = "ChooseCDog"
        Me.ChooseCDog.Size = New System.Drawing.Size(229, 35)
        Me.ChooseCDog.TabIndex = 32
        Me.ChooseCDog.Text = "Choose this dog"
        Me.ChooseCDog.UseVisualStyleBackColor = True
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(58, 136)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(62, 31)
        Me.Label26.TabIndex = 31
        Me.Label26.Text = "Age"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(143, 188)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(171, 31)
        Me.Label27.TabIndex = 30
        Me.Label27.Text = "Recent Form"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(131, 240)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(190, 31)
        Me.Label28.TabIndex = 29
        Me.Label28.Text = "Season Win %"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(50, 84)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(86, 31)
        Me.Label29.TabIndex = 28
        Me.Label29.Text = "Home"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(50, 27)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(86, 31)
        Me.Label30.TabIndex = 27
        Me.Label30.Text = "Name"
        '
        'Label31
        '
        Me.Label31.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(142, 131)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(365, 39)
        Me.Label31.TabIndex = 26
        Me.Label31.Text = "45"
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage1)
        Me.TabControl2.Controls.Add(Me.TabPage2)
        Me.TabControl2.Controls.Add(Me.TabPage3)
        Me.TabControl2.Controls.Add(Me.TabPage4)
        Me.TabControl2.Controls.Add(Me.TabPage5)
        Me.TabControl2.Controls.Add(Me.TabPage6)
        Me.TabControl2.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl2.HotTrack = True
        Me.TabControl2.Location = New System.Drawing.Point(91, 100)
        Me.TabControl2.Multiline = True
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(564, 462)
        Me.TabControl2.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.label200)
        Me.TabPage1.Controls.Add(Me.CountyDogPanel)
        Me.TabPage1.Controls.Add(Me.WinDogPanel)
        Me.TabPage1.Controls.Add(Me.FormDogPanel)
        Me.TabPage1.Controls.Add(Me.ChooseADog)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.AgeDogPanel)
        Me.TabPage1.Location = New System.Drawing.Point(4, 40)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(556, 418)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Dog A"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(307, 288)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(148, 39)
        Me.Label1.TabIndex = 25
        Me.Label1.Text = "3 3 2 1 4"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(75, 290)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(219, 31)
        Me.Label7.TabIndex = 24
        Me.Label7.Text = "Average Position"
        '
        'label200
        '
        Me.label200.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.label200.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label200.Location = New System.Drawing.Point(140, 28)
        Me.label200.Name = "label200"
        Me.label200.Size = New System.Drawing.Size(365, 39)
        Me.label200.TabIndex = 10
        Me.label200.Text = "45"
        '
        'CountyDogPanel
        '
        Me.CountyDogPanel.AutoEllipsis = True
        Me.CountyDogPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.CountyDogPanel.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CountyDogPanel.Location = New System.Drawing.Point(140, 80)
        Me.CountyDogPanel.Name = "CountyDogPanel"
        Me.CountyDogPanel.Size = New System.Drawing.Size(365, 39)
        Me.CountyDogPanel.TabIndex = 9
        Me.CountyDogPanel.Text = "45"
        '
        'WinDogPanel
        '
        Me.WinDogPanel.AutoSize = True
        Me.WinDogPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.WinDogPanel.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.WinDogPanel.Location = New System.Drawing.Point(308, 236)
        Me.WinDogPanel.Name = "WinDogPanel"
        Me.WinDogPanel.Size = New System.Drawing.Size(55, 39)
        Me.WinDogPanel.TabIndex = 8
        Me.WinDogPanel.Text = "45"
        '
        'FormDogPanel
        '
        Me.FormDogPanel.AutoSize = True
        Me.FormDogPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.FormDogPanel.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormDogPanel.Location = New System.Drawing.Point(308, 186)
        Me.FormDogPanel.Name = "FormDogPanel"
        Me.FormDogPanel.Size = New System.Drawing.Size(148, 39)
        Me.FormDogPanel.TabIndex = 7
        Me.FormDogPanel.Text = "3 3 2 1 4"
        '
        'ChooseADog
        '
        Me.ChooseADog.AutoSize = True
        Me.ChooseADog.Location = New System.Drawing.Point(195, 357)
        Me.ChooseADog.Name = "ChooseADog"
        Me.ChooseADog.Size = New System.Drawing.Size(229, 35)
        Me.ChooseADog.TabIndex = 6
        Me.ChooseADog.Text = "Choose this dog"
        Me.ChooseADog.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(58, 136)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(62, 31)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Age"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(131, 189)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(171, 31)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Recent Form"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(112, 241)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(190, 31)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Season Win %"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(48, 85)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(86, 31)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Home"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(48, 28)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(86, 31)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Name"
        '
        'AgeDogPanel
        '
        Me.AgeDogPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.AgeDogPanel.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AgeDogPanel.Location = New System.Drawing.Point(139, 131)
        Me.AgeDogPanel.Name = "AgeDogPanel"
        Me.AgeDogPanel.Size = New System.Drawing.Size(366, 39)
        Me.AgeDogPanel.TabIndex = 0
        Me.AgeDogPanel.Text = "45"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TabPage2.Controls.Add(Me.Label8)
        Me.TabPage2.Controls.Add(Me.Label9)
        Me.TabPage2.Controls.Add(Me.Label10)
        Me.TabPage2.Controls.Add(Me.Label11)
        Me.TabPage2.Controls.Add(Me.Label12)
        Me.TabPage2.Controls.Add(Me.Label13)
        Me.TabPage2.Controls.Add(Me.ChooseBDog)
        Me.TabPage2.Controls.Add(Me.Label14)
        Me.TabPage2.Controls.Add(Me.Label15)
        Me.TabPage2.Controls.Add(Me.Label16)
        Me.TabPage2.Controls.Add(Me.Label17)
        Me.TabPage2.Controls.Add(Me.Label18)
        Me.TabPage2.Controls.Add(Me.Label19)
        Me.TabPage2.Location = New System.Drawing.Point(4, 40)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(556, 418)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Dog B"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(329, 286)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(148, 39)
        Me.Label8.TabIndex = 38
        Me.Label8.Text = "3 3 2 1 4"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(95, 288)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(219, 31)
        Me.Label9.TabIndex = 37
        Me.Label9.Text = "Average Position"
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(143, 26)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(365, 39)
        Me.Label10.TabIndex = 36
        Me.Label10.Text = "45"
        '
        'Label11
        '
        Me.Label11.AutoEllipsis = True
        Me.Label11.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(143, 78)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(365, 39)
        Me.Label11.TabIndex = 35
        Me.Label11.Text = "45"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(330, 234)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(55, 39)
        Me.Label12.TabIndex = 34
        Me.Label12.Text = "45"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(329, 186)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(148, 39)
        Me.Label13.TabIndex = 33
        Me.Label13.Text = "3 3 2 1 4"
        '
        'ChooseBDog
        '
        Me.ChooseBDog.AutoSize = True
        Me.ChooseBDog.Location = New System.Drawing.Point(198, 355)
        Me.ChooseBDog.Name = "ChooseBDog"
        Me.ChooseBDog.Size = New System.Drawing.Size(229, 35)
        Me.ChooseBDog.TabIndex = 32
        Me.ChooseBDog.Text = "Choose this dog"
        Me.ChooseBDog.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(60, 134)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(62, 31)
        Me.Label14.TabIndex = 31
        Me.Label14.Text = "Age"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(143, 191)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(171, 31)
        Me.Label15.TabIndex = 30
        Me.Label15.Text = "Recent Form"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(132, 239)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(190, 31)
        Me.Label16.TabIndex = 29
        Me.Label16.Text = "Season Win %"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(51, 83)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(86, 31)
        Me.Label17.TabIndex = 28
        Me.Label17.Text = "Home"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(51, 26)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(86, 31)
        Me.Label18.TabIndex = 27
        Me.Label18.Text = "Name"
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(143, 129)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(365, 39)
        Me.Label19.TabIndex = 26
        Me.Label19.Text = "45"
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TabPage4.Controls.Add(Me.Label32)
        Me.TabPage4.Controls.Add(Me.Label33)
        Me.TabPage4.Controls.Add(Me.Label34)
        Me.TabPage4.Controls.Add(Me.Label35)
        Me.TabPage4.Controls.Add(Me.Label36)
        Me.TabPage4.Controls.Add(Me.Label37)
        Me.TabPage4.Controls.Add(Me.ChooseDDog)
        Me.TabPage4.Controls.Add(Me.Label38)
        Me.TabPage4.Controls.Add(Me.Label39)
        Me.TabPage4.Controls.Add(Me.Label40)
        Me.TabPage4.Controls.Add(Me.Label41)
        Me.TabPage4.Controls.Add(Me.Label42)
        Me.TabPage4.Controls.Add(Me.Label43)
        Me.TabPage4.Location = New System.Drawing.Point(4, 40)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(556, 418)
        Me.TabPage4.TabIndex = 2
        Me.TabPage4.Text = "Dog D"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(328, 287)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(148, 39)
        Me.Label32.TabIndex = 38
        Me.Label32.Text = "3 3 2 1 4"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(94, 289)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(219, 31)
        Me.Label33.TabIndex = 37
        Me.Label33.Text = "Average Position"
        '
        'Label34
        '
        Me.Label34.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(142, 27)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(365, 39)
        Me.Label34.TabIndex = 36
        Me.Label34.Text = "45"
        '
        'Label35
        '
        Me.Label35.AutoEllipsis = True
        Me.Label35.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(142, 79)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(365, 39)
        Me.Label35.TabIndex = 35
        Me.Label35.Text = "45"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(329, 235)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(55, 39)
        Me.Label36.TabIndex = 34
        Me.Label36.Text = "45"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(327, 183)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(148, 39)
        Me.Label37.TabIndex = 33
        Me.Label37.Text = "3 3 2 1 4"
        '
        'ChooseDDog
        '
        Me.ChooseDDog.AutoSize = True
        Me.ChooseDDog.Location = New System.Drawing.Point(197, 356)
        Me.ChooseDDog.Name = "ChooseDDog"
        Me.ChooseDDog.Size = New System.Drawing.Size(229, 35)
        Me.ChooseDDog.TabIndex = 32
        Me.ChooseDDog.Text = "Choose this dog"
        Me.ChooseDDog.UseVisualStyleBackColor = True
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(57, 136)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(62, 31)
        Me.Label38.TabIndex = 31
        Me.Label38.Text = "Age"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(150, 191)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(171, 31)
        Me.Label39.TabIndex = 30
        Me.Label39.Text = "Recent Form"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(131, 240)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(190, 31)
        Me.Label40.TabIndex = 29
        Me.Label40.Text = "Season Win %"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(50, 84)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(86, 31)
        Me.Label41.TabIndex = 28
        Me.Label41.Text = "Home"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(50, 27)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(86, 31)
        Me.Label42.TabIndex = 27
        Me.Label42.Text = "Name"
        '
        'Label43
        '
        Me.Label43.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(142, 128)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(365, 39)
        Me.Label43.TabIndex = 26
        Me.Label43.Text = "45"
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TabPage5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage5.Controls.Add(Me.Label44)
        Me.TabPage5.Controls.Add(Me.Label45)
        Me.TabPage5.Controls.Add(Me.Label46)
        Me.TabPage5.Controls.Add(Me.Label47)
        Me.TabPage5.Controls.Add(Me.Label48)
        Me.TabPage5.Controls.Add(Me.Label49)
        Me.TabPage5.Controls.Add(Me.ChooseEDog)
        Me.TabPage5.Controls.Add(Me.Label50)
        Me.TabPage5.Controls.Add(Me.Label51)
        Me.TabPage5.Controls.Add(Me.Label52)
        Me.TabPage5.Controls.Add(Me.Label53)
        Me.TabPage5.Controls.Add(Me.Label54)
        Me.TabPage5.Controls.Add(Me.Label55)
        Me.TabPage5.Location = New System.Drawing.Point(4, 40)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(556, 418)
        Me.TabPage5.TabIndex = 3
        Me.TabPage5.Text = "Dog E"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(326, 285)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(148, 39)
        Me.Label44.TabIndex = 38
        Me.Label44.Text = "3 3 2 1 4"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(92, 287)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(219, 31)
        Me.Label45.TabIndex = 37
        Me.Label45.Text = "Average Position"
        '
        'Label46
        '
        Me.Label46.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(140, 25)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(365, 39)
        Me.Label46.TabIndex = 36
        Me.Label46.Text = "45"
        '
        'Label47
        '
        Me.Label47.AutoEllipsis = True
        Me.Label47.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label47.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(140, 77)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(365, 39)
        Me.Label47.TabIndex = 35
        Me.Label47.Text = "45"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label48.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(327, 233)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(55, 39)
        Me.Label48.TabIndex = 34
        Me.Label48.Text = "45"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label49.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(327, 183)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(148, 39)
        Me.Label49.TabIndex = 33
        Me.Label49.Text = "3 3 2 1 4"
        '
        'ChooseEDog
        '
        Me.ChooseEDog.AutoSize = True
        Me.ChooseEDog.Location = New System.Drawing.Point(195, 354)
        Me.ChooseEDog.Name = "ChooseEDog"
        Me.ChooseEDog.Size = New System.Drawing.Size(229, 35)
        Me.ChooseEDog.TabIndex = 32
        Me.ChooseEDog.Text = "Choose this dog"
        Me.ChooseEDog.UseVisualStyleBackColor = True
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(57, 131)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(62, 31)
        Me.Label50.TabIndex = 31
        Me.Label50.Text = "Age"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(144, 187)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(171, 31)
        Me.Label51.TabIndex = 30
        Me.Label51.Text = "Recent Form"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(129, 238)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(190, 31)
        Me.Label52.TabIndex = 29
        Me.Label52.Text = "Season Win %"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(48, 82)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(86, 31)
        Me.Label53.TabIndex = 28
        Me.Label53.Text = "Home"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(48, 25)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(86, 31)
        Me.Label54.TabIndex = 27
        Me.Label54.Text = "Name"
        '
        'Label55
        '
        Me.Label55.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label55.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.Location = New System.Drawing.Point(140, 125)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(365, 39)
        Me.Label55.TabIndex = 26
        Me.Label55.Text = "45"
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TabPage6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage6.Controls.Add(Me.Label56)
        Me.TabPage6.Controls.Add(Me.Label57)
        Me.TabPage6.Controls.Add(Me.Label58)
        Me.TabPage6.Controls.Add(Me.Label59)
        Me.TabPage6.Controls.Add(Me.Label60)
        Me.TabPage6.Controls.Add(Me.Label179)
        Me.TabPage6.Controls.Add(Me.ChooseFDog)
        Me.TabPage6.Controls.Add(Me.Label180)
        Me.TabPage6.Controls.Add(Me.Label181)
        Me.TabPage6.Controls.Add(Me.Label182)
        Me.TabPage6.Controls.Add(Me.Label183)
        Me.TabPage6.Controls.Add(Me.Label184)
        Me.TabPage6.Controls.Add(Me.Label185)
        Me.TabPage6.Location = New System.Drawing.Point(4, 40)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(556, 418)
        Me.TabPage6.TabIndex = 4
        Me.TabPage6.Text = "Dog F"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label56.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.Location = New System.Drawing.Point(326, 285)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(148, 39)
        Me.Label56.TabIndex = 38
        Me.Label56.Text = "3 3 2 1 4"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(92, 287)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(219, 31)
        Me.Label57.TabIndex = 37
        Me.Label57.Text = "Average Position"
        '
        'Label58
        '
        Me.Label58.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label58.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.Location = New System.Drawing.Point(140, 25)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(365, 39)
        Me.Label58.TabIndex = 36
        Me.Label58.Text = "45"
        '
        'Label59
        '
        Me.Label59.AutoEllipsis = True
        Me.Label59.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label59.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.Location = New System.Drawing.Point(140, 77)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(365, 39)
        Me.Label59.TabIndex = 35
        Me.Label59.Text = "45"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label60.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label60.Location = New System.Drawing.Point(327, 233)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(55, 39)
        Me.Label60.TabIndex = 34
        Me.Label60.Text = "45"
        '
        'Label179
        '
        Me.Label179.AutoSize = True
        Me.Label179.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label179.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label179.Location = New System.Drawing.Point(326, 181)
        Me.Label179.Name = "Label179"
        Me.Label179.Size = New System.Drawing.Size(148, 39)
        Me.Label179.TabIndex = 33
        Me.Label179.Text = "3 3 2 1 4"
        '
        'ChooseFDog
        '
        Me.ChooseFDog.AutoSize = True
        Me.ChooseFDog.Location = New System.Drawing.Point(195, 354)
        Me.ChooseFDog.Name = "ChooseFDog"
        Me.ChooseFDog.Size = New System.Drawing.Size(229, 35)
        Me.ChooseFDog.TabIndex = 32
        Me.ChooseFDog.Text = "Choose this dog"
        Me.ChooseFDog.UseVisualStyleBackColor = True
        '
        'Label180
        '
        Me.Label180.AutoSize = True
        Me.Label180.Location = New System.Drawing.Point(57, 132)
        Me.Label180.Name = "Label180"
        Me.Label180.Size = New System.Drawing.Size(62, 31)
        Me.Label180.TabIndex = 31
        Me.Label180.Text = "Age"
        '
        'Label181
        '
        Me.Label181.AutoSize = True
        Me.Label181.Location = New System.Drawing.Point(144, 187)
        Me.Label181.Name = "Label181"
        Me.Label181.Size = New System.Drawing.Size(171, 31)
        Me.Label181.TabIndex = 30
        Me.Label181.Text = "Recent Form"
        '
        'Label182
        '
        Me.Label182.AutoSize = True
        Me.Label182.Location = New System.Drawing.Point(129, 238)
        Me.Label182.Name = "Label182"
        Me.Label182.Size = New System.Drawing.Size(190, 31)
        Me.Label182.TabIndex = 29
        Me.Label182.Text = "Season Win %"
        '
        'Label183
        '
        Me.Label183.AutoSize = True
        Me.Label183.Location = New System.Drawing.Point(48, 82)
        Me.Label183.Name = "Label183"
        Me.Label183.Size = New System.Drawing.Size(86, 31)
        Me.Label183.TabIndex = 28
        Me.Label183.Text = "Home"
        '
        'Label184
        '
        Me.Label184.AutoSize = True
        Me.Label184.Location = New System.Drawing.Point(48, 25)
        Me.Label184.Name = "Label184"
        Me.Label184.Size = New System.Drawing.Size(86, 31)
        Me.Label184.TabIndex = 27
        Me.Label184.Text = "Name"
        '
        'Label185
        '
        Me.Label185.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label185.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label185.Location = New System.Drawing.Point(140, 127)
        Me.Label185.Name = "Label185"
        Me.Label185.Size = New System.Drawing.Size(365, 39)
        Me.Label185.TabIndex = 26
        Me.Label185.Text = "45"
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(275, 599)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(197, 48)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Confirm"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackgroundImage = CType(resources.GetObject("Panel1.BackgroundImage"), System.Drawing.Image)
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.TextBox1)
        Me.Panel1.Location = New System.Drawing.Point(94, 140)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(561, 422)
        Me.Panel1.TabIndex = 3
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox1.Font = New System.Drawing.Font("Comic Sans MS", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(96, 80)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(372, 223)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.Text = "Use the tabs above to view information about each dog." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Use the tabs to the lef" & _
            "t to compare infomation across dogs." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "When you have selected a dog, click the " & _
            "button below to continue."
        '
        'TabPage11
        '
        Me.TabPage11.Controls.Add(Me.Label139)
        Me.TabPage11.Controls.Add(Me.Label140)
        Me.TabPage11.Controls.Add(Me.Label141)
        Me.TabPage11.Controls.Add(Me.Label142)
        Me.TabPage11.Controls.Add(Me.Label143)
        Me.TabPage11.Controls.Add(Me.Label144)
        Me.TabPage11.Controls.Add(Me.Label145)
        Me.TabPage11.Controls.Add(Me.Label146)
        Me.TabPage11.Controls.Add(Me.ChooseBPos)
        Me.TabPage11.Controls.Add(Me.ChooseCPos)
        Me.TabPage11.Controls.Add(Me.ChooseDPos)
        Me.TabPage11.Controls.Add(Me.ChooseEPos)
        Me.TabPage11.Controls.Add(Me.ChooseFPos)
        Me.TabPage11.Controls.Add(Me.Label147)
        Me.TabPage11.Controls.Add(Me.Label148)
        Me.TabPage11.Controls.Add(Me.Label149)
        Me.TabPage11.Controls.Add(Me.Label150)
        Me.TabPage11.Controls.Add(Me.ChooseAPos)
        Me.TabPage11.Controls.Add(Me.Label151)
        Me.TabPage11.Controls.Add(Me.Label152)
        Me.TabPage11.Controls.Add(Me.Label153)
        Me.TabPage11.Controls.Add(Me.Label154)
        Me.TabPage11.Controls.Add(Me.Label155)
        Me.TabPage11.Controls.Add(Me.Label156)
        Me.TabPage11.Controls.Add(Me.Label157)
        Me.TabPage11.Controls.Add(Me.Label158)
        Me.TabPage11.Location = New System.Drawing.Point(54, 4)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage11.Size = New System.Drawing.Size(560, 418)
        Me.TabPage11.TabIndex = 4
        Me.TabPage11.Text = "Avg Pos."
        Me.TabPage11.UseVisualStyleBackColor = True
        '
        'Label139
        '
        Me.Label139.AutoSize = True
        Me.Label139.Location = New System.Drawing.Point(79, 48)
        Me.Label139.Name = "Label139"
        Me.Label139.Size = New System.Drawing.Size(61, 24)
        Me.Label139.TabIndex = 113
        Me.Label139.Text = "Name"
        '
        'Label140
        '
        Me.Label140.AutoSize = True
        Me.Label140.Location = New System.Drawing.Point(270, 36)
        Me.Label140.Name = "Label140"
        Me.Label140.Size = New System.Drawing.Size(129, 48)
        Me.Label140.TabIndex = 112
        Me.Label140.Text = "Average finish" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " position"
        '
        'Label141
        '
        Me.Label141.AutoEllipsis = True
        Me.Label141.Location = New System.Drawing.Point(79, 335)
        Me.Label141.Name = "Label141"
        Me.Label141.Size = New System.Drawing.Size(184, 31)
        Me.Label141.TabIndex = 111
        Me.Label141.Text = "----"
        '
        'Label142
        '
        Me.Label142.AutoEllipsis = True
        Me.Label142.Location = New System.Drawing.Point(79, 288)
        Me.Label142.Name = "Label142"
        Me.Label142.Size = New System.Drawing.Size(184, 31)
        Me.Label142.TabIndex = 110
        Me.Label142.Text = "SillyDogname"
        '
        'Label143
        '
        Me.Label143.AutoEllipsis = True
        Me.Label143.Location = New System.Drawing.Point(79, 241)
        Me.Label143.Name = "Label143"
        Me.Label143.Size = New System.Drawing.Size(184, 31)
        Me.Label143.TabIndex = 109
        Me.Label143.Text = "SillyDogname"
        '
        'Label144
        '
        Me.Label144.AutoEllipsis = True
        Me.Label144.Location = New System.Drawing.Point(79, 194)
        Me.Label144.Name = "Label144"
        Me.Label144.Size = New System.Drawing.Size(184, 31)
        Me.Label144.TabIndex = 108
        Me.Label144.Text = "SillyDogname"
        '
        'Label145
        '
        Me.Label145.AutoEllipsis = True
        Me.Label145.Location = New System.Drawing.Point(79, 147)
        Me.Label145.Name = "Label145"
        Me.Label145.Size = New System.Drawing.Size(184, 31)
        Me.Label145.TabIndex = 107
        Me.Label145.Text = "SillyDogname"
        '
        'Label146
        '
        Me.Label146.AutoEllipsis = True
        Me.Label146.Location = New System.Drawing.Point(79, 100)
        Me.Label146.Name = "Label146"
        Me.Label146.Size = New System.Drawing.Size(184, 31)
        Me.Label146.TabIndex = 106
        Me.Label146.Text = "SillyDogname"
        '
        'ChooseBPos
        '
        Me.ChooseBPos.AutoSize = True
        Me.ChooseBPos.Location = New System.Drawing.Point(446, 147)
        Me.ChooseBPos.Name = "ChooseBPos"
        Me.ChooseBPos.Size = New System.Drawing.Size(95, 28)
        Me.ChooseBPos.TabIndex = 105
        Me.ChooseBPos.Text = "Choose"
        Me.ChooseBPos.UseVisualStyleBackColor = True
        '
        'ChooseCPos
        '
        Me.ChooseCPos.AutoSize = True
        Me.ChooseCPos.Location = New System.Drawing.Point(446, 194)
        Me.ChooseCPos.Name = "ChooseCPos"
        Me.ChooseCPos.Size = New System.Drawing.Size(95, 28)
        Me.ChooseCPos.TabIndex = 104
        Me.ChooseCPos.Text = "Choose"
        Me.ChooseCPos.UseVisualStyleBackColor = True
        '
        'ChooseDPos
        '
        Me.ChooseDPos.AutoSize = True
        Me.ChooseDPos.Location = New System.Drawing.Point(446, 241)
        Me.ChooseDPos.Name = "ChooseDPos"
        Me.ChooseDPos.Size = New System.Drawing.Size(95, 28)
        Me.ChooseDPos.TabIndex = 103
        Me.ChooseDPos.Text = "Choose"
        Me.ChooseDPos.UseVisualStyleBackColor = True
        '
        'ChooseEPos
        '
        Me.ChooseEPos.AutoSize = True
        Me.ChooseEPos.Location = New System.Drawing.Point(446, 288)
        Me.ChooseEPos.Name = "ChooseEPos"
        Me.ChooseEPos.Size = New System.Drawing.Size(95, 28)
        Me.ChooseEPos.TabIndex = 102
        Me.ChooseEPos.Text = "Choose"
        Me.ChooseEPos.UseVisualStyleBackColor = True
        '
        'ChooseFPos
        '
        Me.ChooseFPos.AutoSize = True
        Me.ChooseFPos.Location = New System.Drawing.Point(446, 335)
        Me.ChooseFPos.Name = "ChooseFPos"
        Me.ChooseFPos.Size = New System.Drawing.Size(95, 28)
        Me.ChooseFPos.TabIndex = 101
        Me.ChooseFPos.Text = "Choose"
        Me.ChooseFPos.UseVisualStyleBackColor = True
        '
        'Label147
        '
        Me.Label147.AutoSize = True
        Me.Label147.Location = New System.Drawing.Point(41, 335)
        Me.Label147.Name = "Label147"
        Me.Label147.Size = New System.Drawing.Size(22, 24)
        Me.Label147.TabIndex = 100
        Me.Label147.Text = "F"
        '
        'Label148
        '
        Me.Label148.AutoEllipsis = True
        Me.Label148.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label148.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label148.Location = New System.Drawing.Point(269, 331)
        Me.Label148.Name = "Label148"
        Me.Label148.Size = New System.Drawing.Size(149, 39)
        Me.Label148.TabIndex = 99
        Me.Label148.Text = "----"
        Me.Label148.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label149
        '
        Me.Label149.AutoSize = True
        Me.Label149.Location = New System.Drawing.Point(41, 194)
        Me.Label149.Name = "Label149"
        Me.Label149.Size = New System.Drawing.Size(23, 24)
        Me.Label149.TabIndex = 98
        Me.Label149.Text = "C"
        '
        'Label150
        '
        Me.Label150.AutoEllipsis = True
        Me.Label150.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label150.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label150.Location = New System.Drawing.Point(269, 190)
        Me.Label150.Name = "Label150"
        Me.Label150.Size = New System.Drawing.Size(149, 39)
        Me.Label150.TabIndex = 97
        Me.Label150.Text = "Bristol"
        Me.Label150.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ChooseAPos
        '
        Me.ChooseAPos.AutoSize = True
        Me.ChooseAPos.Location = New System.Drawing.Point(446, 100)
        Me.ChooseAPos.Name = "ChooseAPos"
        Me.ChooseAPos.Size = New System.Drawing.Size(95, 28)
        Me.ChooseAPos.TabIndex = 96
        Me.ChooseAPos.Text = "Choose"
        Me.ChooseAPos.UseVisualStyleBackColor = True
        '
        'Label151
        '
        Me.Label151.AutoSize = True
        Me.Label151.Location = New System.Drawing.Point(41, 100)
        Me.Label151.Name = "Label151"
        Me.Label151.Size = New System.Drawing.Size(23, 24)
        Me.Label151.TabIndex = 95
        Me.Label151.Text = "A"
        '
        'Label152
        '
        Me.Label152.AutoEllipsis = True
        Me.Label152.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label152.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label152.Location = New System.Drawing.Point(269, 96)
        Me.Label152.Name = "Label152"
        Me.Label152.Size = New System.Drawing.Size(149, 39)
        Me.Label152.TabIndex = 94
        Me.Label152.Text = "London"
        Me.Label152.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label153
        '
        Me.Label153.AutoSize = True
        Me.Label153.Location = New System.Drawing.Point(41, 288)
        Me.Label153.Name = "Label153"
        Me.Label153.Size = New System.Drawing.Size(23, 24)
        Me.Label153.TabIndex = 93
        Me.Label153.Text = "E"
        '
        'Label154
        '
        Me.Label154.AutoEllipsis = True
        Me.Label154.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label154.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label154.Location = New System.Drawing.Point(269, 284)
        Me.Label154.Name = "Label154"
        Me.Label154.Size = New System.Drawing.Size(149, 39)
        Me.Label154.TabIndex = 92
        Me.Label154.Text = "Wrexham"
        Me.Label154.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label155
        '
        Me.Label155.AutoSize = True
        Me.Label155.Location = New System.Drawing.Point(41, 241)
        Me.Label155.Name = "Label155"
        Me.Label155.Size = New System.Drawing.Size(23, 24)
        Me.Label155.TabIndex = 91
        Me.Label155.Text = "D"
        '
        'Label156
        '
        Me.Label156.AutoEllipsis = True
        Me.Label156.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label156.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label156.Location = New System.Drawing.Point(269, 237)
        Me.Label156.Name = "Label156"
        Me.Label156.Size = New System.Drawing.Size(149, 39)
        Me.Label156.TabIndex = 90
        Me.Label156.Text = "Bradford"
        Me.Label156.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label157
        '
        Me.Label157.AutoSize = True
        Me.Label157.Location = New System.Drawing.Point(41, 147)
        Me.Label157.Name = "Label157"
        Me.Label157.Size = New System.Drawing.Size(22, 24)
        Me.Label157.TabIndex = 89
        Me.Label157.Text = "B"
        '
        'Label158
        '
        Me.Label158.AutoEllipsis = True
        Me.Label158.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label158.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label158.Location = New System.Drawing.Point(269, 143)
        Me.Label158.Name = "Label158"
        Me.Label158.Size = New System.Drawing.Size(149, 39)
        Me.Label158.TabIndex = 88
        Me.Label158.Text = "Cardiff"
        Me.Label158.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TabPage10
        '
        Me.TabPage10.Controls.Add(Me.Label159)
        Me.TabPage10.Controls.Add(Me.Label160)
        Me.TabPage10.Controls.Add(Me.Label161)
        Me.TabPage10.Controls.Add(Me.Label162)
        Me.TabPage10.Controls.Add(Me.Label163)
        Me.TabPage10.Controls.Add(Me.Label164)
        Me.TabPage10.Controls.Add(Me.Label165)
        Me.TabPage10.Controls.Add(Me.Label166)
        Me.TabPage10.Controls.Add(Me.ChooseBWin)
        Me.TabPage10.Controls.Add(Me.ChooseCWin)
        Me.TabPage10.Controls.Add(Me.ChooseDWin)
        Me.TabPage10.Controls.Add(Me.ChooseEWin)
        Me.TabPage10.Controls.Add(Me.ChooseFWin)
        Me.TabPage10.Controls.Add(Me.Label167)
        Me.TabPage10.Controls.Add(Me.Label168)
        Me.TabPage10.Controls.Add(Me.Label169)
        Me.TabPage10.Controls.Add(Me.Label170)
        Me.TabPage10.Controls.Add(Me.ChooseAWin)
        Me.TabPage10.Controls.Add(Me.Label171)
        Me.TabPage10.Controls.Add(Me.Label172)
        Me.TabPage10.Controls.Add(Me.Label173)
        Me.TabPage10.Controls.Add(Me.Label174)
        Me.TabPage10.Controls.Add(Me.Label175)
        Me.TabPage10.Controls.Add(Me.Label176)
        Me.TabPage10.Controls.Add(Me.Label177)
        Me.TabPage10.Controls.Add(Me.Label178)
        Me.TabPage10.Location = New System.Drawing.Point(54, 4)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage10.Size = New System.Drawing.Size(560, 418)
        Me.TabPage10.TabIndex = 5
        Me.TabPage10.Text = "Seas. Win %"
        Me.TabPage10.UseVisualStyleBackColor = True
        '
        'Label159
        '
        Me.Label159.AutoSize = True
        Me.Label159.Location = New System.Drawing.Point(79, 48)
        Me.Label159.Name = "Label159"
        Me.Label159.Size = New System.Drawing.Size(61, 24)
        Me.Label159.TabIndex = 113
        Me.Label159.Text = "Name"
        '
        'Label160
        '
        Me.Label160.AutoSize = True
        Me.Label160.Location = New System.Drawing.Point(296, 48)
        Me.Label160.Name = "Label160"
        Me.Label160.Size = New System.Drawing.Size(132, 24)
        Me.Label160.TabIndex = 112
        Me.Label160.Text = "Season Win %"
        '
        'Label161
        '
        Me.Label161.AutoEllipsis = True
        Me.Label161.Location = New System.Drawing.Point(79, 335)
        Me.Label161.Name = "Label161"
        Me.Label161.Size = New System.Drawing.Size(214, 31)
        Me.Label161.TabIndex = 111
        Me.Label161.Text = "SillyDogname"
        '
        'Label162
        '
        Me.Label162.AutoEllipsis = True
        Me.Label162.Location = New System.Drawing.Point(79, 288)
        Me.Label162.Name = "Label162"
        Me.Label162.Size = New System.Drawing.Size(214, 31)
        Me.Label162.TabIndex = 110
        Me.Label162.Text = "SillyDogname"
        '
        'Label163
        '
        Me.Label163.AutoEllipsis = True
        Me.Label163.Location = New System.Drawing.Point(79, 241)
        Me.Label163.Name = "Label163"
        Me.Label163.Size = New System.Drawing.Size(214, 31)
        Me.Label163.TabIndex = 109
        Me.Label163.Text = "SillyDogname"
        '
        'Label164
        '
        Me.Label164.AutoEllipsis = True
        Me.Label164.Location = New System.Drawing.Point(79, 194)
        Me.Label164.Name = "Label164"
        Me.Label164.Size = New System.Drawing.Size(214, 31)
        Me.Label164.TabIndex = 108
        Me.Label164.Text = "SillyDogname"
        '
        'Label165
        '
        Me.Label165.AutoEllipsis = True
        Me.Label165.Location = New System.Drawing.Point(79, 147)
        Me.Label165.Name = "Label165"
        Me.Label165.Size = New System.Drawing.Size(214, 31)
        Me.Label165.TabIndex = 107
        Me.Label165.Text = "SillyDogname"
        '
        'Label166
        '
        Me.Label166.AutoEllipsis = True
        Me.Label166.Location = New System.Drawing.Point(79, 100)
        Me.Label166.Name = "Label166"
        Me.Label166.Size = New System.Drawing.Size(214, 31)
        Me.Label166.TabIndex = 106
        Me.Label166.Text = "SillyDogname"
        '
        'ChooseBWin
        '
        Me.ChooseBWin.AutoSize = True
        Me.ChooseBWin.Location = New System.Drawing.Point(459, 147)
        Me.ChooseBWin.Name = "ChooseBWin"
        Me.ChooseBWin.Size = New System.Drawing.Size(95, 28)
        Me.ChooseBWin.TabIndex = 105
        Me.ChooseBWin.Text = "Choose"
        Me.ChooseBWin.UseVisualStyleBackColor = True
        '
        'ChooseCWin
        '
        Me.ChooseCWin.AutoSize = True
        Me.ChooseCWin.Location = New System.Drawing.Point(459, 194)
        Me.ChooseCWin.Name = "ChooseCWin"
        Me.ChooseCWin.Size = New System.Drawing.Size(95, 28)
        Me.ChooseCWin.TabIndex = 104
        Me.ChooseCWin.Text = "Choose"
        Me.ChooseCWin.UseVisualStyleBackColor = True
        '
        'ChooseDWin
        '
        Me.ChooseDWin.AutoSize = True
        Me.ChooseDWin.Location = New System.Drawing.Point(459, 241)
        Me.ChooseDWin.Name = "ChooseDWin"
        Me.ChooseDWin.Size = New System.Drawing.Size(95, 28)
        Me.ChooseDWin.TabIndex = 103
        Me.ChooseDWin.Text = "Choose"
        Me.ChooseDWin.UseVisualStyleBackColor = True
        '
        'ChooseEWin
        '
        Me.ChooseEWin.AutoSize = True
        Me.ChooseEWin.Location = New System.Drawing.Point(459, 288)
        Me.ChooseEWin.Name = "ChooseEWin"
        Me.ChooseEWin.Size = New System.Drawing.Size(95, 28)
        Me.ChooseEWin.TabIndex = 102
        Me.ChooseEWin.Text = "Choose"
        Me.ChooseEWin.UseVisualStyleBackColor = True
        '
        'ChooseFWin
        '
        Me.ChooseFWin.AutoSize = True
        Me.ChooseFWin.Location = New System.Drawing.Point(459, 338)
        Me.ChooseFWin.Name = "ChooseFWin"
        Me.ChooseFWin.Size = New System.Drawing.Size(95, 28)
        Me.ChooseFWin.TabIndex = 101
        Me.ChooseFWin.Text = "Choose"
        Me.ChooseFWin.UseVisualStyleBackColor = True
        '
        'Label167
        '
        Me.Label167.AutoSize = True
        Me.Label167.Location = New System.Drawing.Point(41, 335)
        Me.Label167.Name = "Label167"
        Me.Label167.Size = New System.Drawing.Size(22, 24)
        Me.Label167.TabIndex = 100
        Me.Label167.Text = "F"
        '
        'Label168
        '
        Me.Label168.AutoEllipsis = True
        Me.Label168.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label168.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label168.Location = New System.Drawing.Point(299, 331)
        Me.Label168.Name = "Label168"
        Me.Label168.Size = New System.Drawing.Size(119, 39)
        Me.Label168.TabIndex = 99
        Me.Label168.Text = "Cambridge"
        Me.Label168.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label169
        '
        Me.Label169.AutoSize = True
        Me.Label169.Location = New System.Drawing.Point(41, 194)
        Me.Label169.Name = "Label169"
        Me.Label169.Size = New System.Drawing.Size(23, 24)
        Me.Label169.TabIndex = 98
        Me.Label169.Text = "C"
        '
        'Label170
        '
        Me.Label170.AutoEllipsis = True
        Me.Label170.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label170.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label170.Location = New System.Drawing.Point(299, 190)
        Me.Label170.Name = "Label170"
        Me.Label170.Size = New System.Drawing.Size(119, 39)
        Me.Label170.TabIndex = 97
        Me.Label170.Text = "Bristol"
        Me.Label170.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ChooseAWin
        '
        Me.ChooseAWin.AutoSize = True
        Me.ChooseAWin.Location = New System.Drawing.Point(459, 100)
        Me.ChooseAWin.Name = "ChooseAWin"
        Me.ChooseAWin.Size = New System.Drawing.Size(95, 28)
        Me.ChooseAWin.TabIndex = 96
        Me.ChooseAWin.Text = "Choose"
        Me.ChooseAWin.UseVisualStyleBackColor = True
        '
        'Label171
        '
        Me.Label171.AutoSize = True
        Me.Label171.Location = New System.Drawing.Point(41, 100)
        Me.Label171.Name = "Label171"
        Me.Label171.Size = New System.Drawing.Size(23, 24)
        Me.Label171.TabIndex = 95
        Me.Label171.Text = "A"
        '
        'Label172
        '
        Me.Label172.AutoEllipsis = True
        Me.Label172.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label172.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label172.Location = New System.Drawing.Point(299, 96)
        Me.Label172.Name = "Label172"
        Me.Label172.Size = New System.Drawing.Size(119, 39)
        Me.Label172.TabIndex = 94
        Me.Label172.Text = "London"
        Me.Label172.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label173
        '
        Me.Label173.AutoSize = True
        Me.Label173.Location = New System.Drawing.Point(41, 288)
        Me.Label173.Name = "Label173"
        Me.Label173.Size = New System.Drawing.Size(23, 24)
        Me.Label173.TabIndex = 93
        Me.Label173.Text = "E"
        '
        'Label174
        '
        Me.Label174.AutoEllipsis = True
        Me.Label174.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label174.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label174.Location = New System.Drawing.Point(299, 284)
        Me.Label174.Name = "Label174"
        Me.Label174.Size = New System.Drawing.Size(119, 39)
        Me.Label174.TabIndex = 92
        Me.Label174.Text = "Wrexham"
        Me.Label174.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label175
        '
        Me.Label175.AutoSize = True
        Me.Label175.Location = New System.Drawing.Point(41, 241)
        Me.Label175.Name = "Label175"
        Me.Label175.Size = New System.Drawing.Size(23, 24)
        Me.Label175.TabIndex = 91
        Me.Label175.Text = "D"
        '
        'Label176
        '
        Me.Label176.AutoEllipsis = True
        Me.Label176.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label176.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label176.Location = New System.Drawing.Point(299, 237)
        Me.Label176.Name = "Label176"
        Me.Label176.Size = New System.Drawing.Size(119, 39)
        Me.Label176.TabIndex = 90
        Me.Label176.Text = "Bradford"
        Me.Label176.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label177
        '
        Me.Label177.AutoSize = True
        Me.Label177.Location = New System.Drawing.Point(41, 147)
        Me.Label177.Name = "Label177"
        Me.Label177.Size = New System.Drawing.Size(22, 24)
        Me.Label177.TabIndex = 89
        Me.Label177.Text = "B"
        '
        'Label178
        '
        Me.Label178.AutoEllipsis = True
        Me.Label178.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label178.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label178.Location = New System.Drawing.Point(299, 143)
        Me.Label178.Name = "Label178"
        Me.Label178.Size = New System.Drawing.Size(119, 39)
        Me.Label178.TabIndex = 88
        Me.Label178.Text = "Cardiff"
        Me.Label178.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.Label79)
        Me.TabPage9.Controls.Add(Me.Label78)
        Me.TabPage9.Controls.Add(Me.Label77)
        Me.TabPage9.Controls.Add(Me.Label76)
        Me.TabPage9.Controls.Add(Me.Label75)
        Me.TabPage9.Controls.Add(Me.Label74)
        Me.TabPage9.Controls.Add(Me.Label73)
        Me.TabPage9.Controls.Add(Me.ChooseBAge)
        Me.TabPage9.Controls.Add(Me.ChooseCAge)
        Me.TabPage9.Controls.Add(Me.ChooseEAge)
        Me.TabPage9.Controls.Add(Me.ChooseDAge)
        Me.TabPage9.Controls.Add(Me.ChooseFAge)
        Me.TabPage9.Controls.Add(Me.Label71)
        Me.TabPage9.Controls.Add(Me.Label72)
        Me.TabPage9.Controls.Add(Me.Label69)
        Me.TabPage9.Controls.Add(Me.Label70)
        Me.TabPage9.Controls.Add(Me.ChooseAAge)
        Me.TabPage9.Controls.Add(Me.Label67)
        Me.TabPage9.Controls.Add(Me.Label68)
        Me.TabPage9.Controls.Add(Me.Label65)
        Me.TabPage9.Controls.Add(Me.Label66)
        Me.TabPage9.Controls.Add(Me.Label63)
        Me.TabPage9.Controls.Add(Me.Label64)
        Me.TabPage9.Controls.Add(Me.Label61)
        Me.TabPage9.Controls.Add(Me.Label62)
        Me.TabPage9.Location = New System.Drawing.Point(54, 4)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(560, 418)
        Me.TabPage9.TabIndex = 0
        Me.TabPage9.Text = "Age"
        Me.TabPage9.UseVisualStyleBackColor = True
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Location = New System.Drawing.Point(302, 24)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(45, 24)
        Me.Label79.TabIndex = 35
        Me.Label79.Text = "Age"
        '
        'Label78
        '
        Me.Label78.AutoEllipsis = True
        Me.Label78.Location = New System.Drawing.Point(65, 292)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(164, 31)
        Me.Label78.TabIndex = 34
        Me.Label78.Text = "----"
        '
        'Label77
        '
        Me.Label77.AutoEllipsis = True
        Me.Label77.Location = New System.Drawing.Point(65, 245)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(164, 31)
        Me.Label77.TabIndex = 33
        Me.Label77.Text = "SillyDogname"
        '
        'Label76
        '
        Me.Label76.AutoEllipsis = True
        Me.Label76.Location = New System.Drawing.Point(65, 198)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(164, 31)
        Me.Label76.TabIndex = 32
        Me.Label76.Text = "SillyDogname"
        '
        'Label75
        '
        Me.Label75.AutoEllipsis = True
        Me.Label75.Location = New System.Drawing.Point(65, 151)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(164, 31)
        Me.Label75.TabIndex = 31
        Me.Label75.Text = "SillyDogname"
        '
        'Label74
        '
        Me.Label74.AutoEllipsis = True
        Me.Label74.Location = New System.Drawing.Point(65, 104)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(164, 31)
        Me.Label74.TabIndex = 30
        Me.Label74.Text = "SillyDogname"
        '
        'Label73
        '
        Me.Label73.AutoEllipsis = True
        Me.Label73.Location = New System.Drawing.Point(65, 57)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(164, 31)
        Me.Label73.TabIndex = 29
        Me.Label73.Text = "SillyDogname"
        '
        'ChooseBAge
        '
        Me.ChooseBAge.AutoSize = True
        Me.ChooseBAge.Location = New System.Drawing.Point(459, 105)
        Me.ChooseBAge.Name = "ChooseBAge"
        Me.ChooseBAge.Size = New System.Drawing.Size(95, 28)
        Me.ChooseBAge.TabIndex = 28
        Me.ChooseBAge.Text = "Choose"
        Me.ChooseBAge.UseVisualStyleBackColor = True
        '
        'ChooseCAge
        '
        Me.ChooseCAge.AutoSize = True
        Me.ChooseCAge.Location = New System.Drawing.Point(459, 152)
        Me.ChooseCAge.Name = "ChooseCAge"
        Me.ChooseCAge.Size = New System.Drawing.Size(95, 28)
        Me.ChooseCAge.TabIndex = 27
        Me.ChooseCAge.Text = "Choose"
        Me.ChooseCAge.UseVisualStyleBackColor = True
        '
        'ChooseEAge
        '
        Me.ChooseEAge.AutoSize = True
        Me.ChooseEAge.Location = New System.Drawing.Point(459, 199)
        Me.ChooseEAge.Name = "ChooseEAge"
        Me.ChooseEAge.Size = New System.Drawing.Size(95, 28)
        Me.ChooseEAge.TabIndex = 26
        Me.ChooseEAge.Text = "Choose"
        Me.ChooseEAge.UseVisualStyleBackColor = True
        '
        'ChooseDAge
        '
        Me.ChooseDAge.AutoSize = True
        Me.ChooseDAge.Location = New System.Drawing.Point(459, 246)
        Me.ChooseDAge.Name = "ChooseDAge"
        Me.ChooseDAge.Size = New System.Drawing.Size(95, 28)
        Me.ChooseDAge.TabIndex = 25
        Me.ChooseDAge.Text = "Choose"
        Me.ChooseDAge.UseVisualStyleBackColor = True
        '
        'ChooseFAge
        '
        Me.ChooseFAge.AutoSize = True
        Me.ChooseFAge.Location = New System.Drawing.Point(459, 293)
        Me.ChooseFAge.Name = "ChooseFAge"
        Me.ChooseFAge.Size = New System.Drawing.Size(95, 28)
        Me.ChooseFAge.TabIndex = 24
        Me.ChooseFAge.Text = "Choose"
        Me.ChooseFAge.UseVisualStyleBackColor = True
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Location = New System.Drawing.Point(9, 295)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(22, 24)
        Me.Label71.TabIndex = 23
        Me.Label71.Text = "F"
        '
        'Label72
        '
        Me.Label72.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label72.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label72.Location = New System.Drawing.Point(237, 288)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(193, 39)
        Me.Label72.TabIndex = 22
        Me.Label72.Text = "----"
        Me.Label72.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Location = New System.Drawing.Point(9, 154)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(23, 24)
        Me.Label69.TabIndex = 20
        Me.Label69.Text = "C"
        '
        'Label70
        '
        Me.Label70.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label70.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label70.Location = New System.Drawing.Point(237, 147)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(193, 39)
        Me.Label70.TabIndex = 19
        Me.Label70.Text = "45"
        Me.Label70.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ChooseAAge
        '
        Me.ChooseAAge.AutoSize = True
        Me.ChooseAAge.Location = New System.Drawing.Point(459, 58)
        Me.ChooseAAge.Name = "ChooseAAge"
        Me.ChooseAAge.Size = New System.Drawing.Size(95, 28)
        Me.ChooseAAge.TabIndex = 18
        Me.ChooseAAge.Text = "Choose"
        Me.ChooseAAge.UseVisualStyleBackColor = True
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Location = New System.Drawing.Point(9, 60)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(23, 24)
        Me.Label67.TabIndex = 17
        Me.Label67.Text = "A"
        '
        'Label68
        '
        Me.Label68.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label68.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label68.Location = New System.Drawing.Point(237, 53)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(193, 39)
        Me.Label68.TabIndex = 16
        Me.Label68.Text = "45"
        Me.Label68.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(9, 248)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(23, 24)
        Me.Label65.TabIndex = 14
        Me.Label65.Text = "E"
        '
        'Label66
        '
        Me.Label66.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label66.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label66.Location = New System.Drawing.Point(237, 241)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(193, 39)
        Me.Label66.TabIndex = 13
        Me.Label66.Text = "45"
        Me.Label66.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(9, 201)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(23, 24)
        Me.Label63.TabIndex = 11
        Me.Label63.Text = "D"
        '
        'Label64
        '
        Me.Label64.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label64.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label64.Location = New System.Drawing.Point(237, 194)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(193, 39)
        Me.Label64.TabIndex = 10
        Me.Label64.Text = "45"
        Me.Label64.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(9, 107)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(22, 24)
        Me.Label61.TabIndex = 8
        Me.Label61.Text = "B"
        '
        'Label62
        '
        Me.Label62.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label62.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label62.Location = New System.Drawing.Point(237, 100)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(193, 39)
        Me.Label62.TabIndex = 7
        Me.Label62.Text = "45"
        Me.Label62.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.Label99)
        Me.TabPage8.Controls.Add(Me.Label100)
        Me.TabPage8.Controls.Add(Me.Label101)
        Me.TabPage8.Controls.Add(Me.Label102)
        Me.TabPage8.Controls.Add(Me.Label103)
        Me.TabPage8.Controls.Add(Me.Label104)
        Me.TabPage8.Controls.Add(Me.Label105)
        Me.TabPage8.Controls.Add(Me.Label106)
        Me.TabPage8.Controls.Add(Me.ChooseBForm)
        Me.TabPage8.Controls.Add(Me.ChooseCForm)
        Me.TabPage8.Controls.Add(Me.ChooseDForm)
        Me.TabPage8.Controls.Add(Me.ChooseEform)
        Me.TabPage8.Controls.Add(Me.ChooseFForm)
        Me.TabPage8.Controls.Add(Me.Label107)
        Me.TabPage8.Controls.Add(Me.Label108)
        Me.TabPage8.Controls.Add(Me.Label109)
        Me.TabPage8.Controls.Add(Me.Label110)
        Me.TabPage8.Controls.Add(Me.ChooseAForm)
        Me.TabPage8.Controls.Add(Me.Label111)
        Me.TabPage8.Controls.Add(Me.Label112)
        Me.TabPage8.Controls.Add(Me.Label113)
        Me.TabPage8.Controls.Add(Me.Label114)
        Me.TabPage8.Controls.Add(Me.Label115)
        Me.TabPage8.Controls.Add(Me.Label116)
        Me.TabPage8.Controls.Add(Me.Label117)
        Me.TabPage8.Controls.Add(Me.Label138)
        Me.TabPage8.Location = New System.Drawing.Point(54, 4)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(560, 418)
        Me.TabPage8.TabIndex = 2
        Me.TabPage8.Text = "Form"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'Label99
        '
        Me.Label99.AutoSize = True
        Me.Label99.Location = New System.Drawing.Point(45, 17)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(61, 24)
        Me.Label99.TabIndex = 87
        Me.Label99.Text = "Name"
        '
        'Label100
        '
        Me.Label100.AutoSize = True
        Me.Label100.Location = New System.Drawing.Point(269, 17)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(112, 24)
        Me.Label100.TabIndex = 86
        Me.Label100.Text = "Recent form"
        '
        'Label101
        '
        Me.Label101.AutoEllipsis = True
        Me.Label101.Location = New System.Drawing.Point(45, 304)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(214, 31)
        Me.Label101.TabIndex = 85
        Me.Label101.Text = "SillyDogname"
        '
        'Label102
        '
        Me.Label102.AutoEllipsis = True
        Me.Label102.Location = New System.Drawing.Point(45, 257)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(214, 31)
        Me.Label102.TabIndex = 84
        Me.Label102.Text = "SillyDogname"
        '
        'Label103
        '
        Me.Label103.AutoEllipsis = True
        Me.Label103.Location = New System.Drawing.Point(45, 210)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(214, 31)
        Me.Label103.TabIndex = 83
        Me.Label103.Text = "SillyDogname"
        '
        'Label104
        '
        Me.Label104.AutoEllipsis = True
        Me.Label104.Location = New System.Drawing.Point(45, 163)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(214, 31)
        Me.Label104.TabIndex = 82
        Me.Label104.Text = "SillyDogname"
        '
        'Label105
        '
        Me.Label105.AutoEllipsis = True
        Me.Label105.Location = New System.Drawing.Point(45, 116)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(214, 31)
        Me.Label105.TabIndex = 81
        Me.Label105.Text = "SillyDogname"
        '
        'Label106
        '
        Me.Label106.AutoEllipsis = True
        Me.Label106.Location = New System.Drawing.Point(45, 69)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(214, 31)
        Me.Label106.TabIndex = 80
        Me.Label106.Text = "SillyDogname"
        '
        'ChooseBForm
        '
        Me.ChooseBForm.AutoSize = True
        Me.ChooseBForm.Location = New System.Drawing.Point(438, 116)
        Me.ChooseBForm.Name = "ChooseBForm"
        Me.ChooseBForm.Size = New System.Drawing.Size(95, 28)
        Me.ChooseBForm.TabIndex = 79
        Me.ChooseBForm.Text = "Choose"
        Me.ChooseBForm.UseVisualStyleBackColor = True
        '
        'ChooseCForm
        '
        Me.ChooseCForm.AutoSize = True
        Me.ChooseCForm.Location = New System.Drawing.Point(438, 163)
        Me.ChooseCForm.Name = "ChooseCForm"
        Me.ChooseCForm.Size = New System.Drawing.Size(95, 28)
        Me.ChooseCForm.TabIndex = 78
        Me.ChooseCForm.Text = "Choose"
        Me.ChooseCForm.UseVisualStyleBackColor = True
        '
        'ChooseDForm
        '
        Me.ChooseDForm.AutoSize = True
        Me.ChooseDForm.Location = New System.Drawing.Point(438, 210)
        Me.ChooseDForm.Name = "ChooseDForm"
        Me.ChooseDForm.Size = New System.Drawing.Size(95, 28)
        Me.ChooseDForm.TabIndex = 77
        Me.ChooseDForm.Text = "Choose"
        Me.ChooseDForm.UseVisualStyleBackColor = True
        '
        'ChooseEform
        '
        Me.ChooseEform.AutoSize = True
        Me.ChooseEform.Location = New System.Drawing.Point(438, 257)
        Me.ChooseEform.Name = "ChooseEform"
        Me.ChooseEform.Size = New System.Drawing.Size(95, 28)
        Me.ChooseEform.TabIndex = 76
        Me.ChooseEform.Text = "Choose"
        Me.ChooseEform.UseVisualStyleBackColor = True
        '
        'ChooseFForm
        '
        Me.ChooseFForm.AutoSize = True
        Me.ChooseFForm.Location = New System.Drawing.Point(438, 304)
        Me.ChooseFForm.Name = "ChooseFForm"
        Me.ChooseFForm.Size = New System.Drawing.Size(95, 28)
        Me.ChooseFForm.TabIndex = 75
        Me.ChooseFForm.Text = "Choose"
        Me.ChooseFForm.UseVisualStyleBackColor = True
        '
        'Label107
        '
        Me.Label107.AutoSize = True
        Me.Label107.Location = New System.Drawing.Point(7, 304)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(22, 24)
        Me.Label107.TabIndex = 74
        Me.Label107.Text = "F"
        '
        'Label108
        '
        Me.Label108.AutoEllipsis = True
        Me.Label108.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label108.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label108.Location = New System.Drawing.Point(265, 300)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(119, 39)
        Me.Label108.TabIndex = 73
        Me.Label108.Text = "Cambridge"
        Me.Label108.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label109
        '
        Me.Label109.AutoSize = True
        Me.Label109.Location = New System.Drawing.Point(7, 163)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(23, 24)
        Me.Label109.TabIndex = 72
        Me.Label109.Text = "C"
        '
        'Label110
        '
        Me.Label110.AutoEllipsis = True
        Me.Label110.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label110.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label110.Location = New System.Drawing.Point(265, 159)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(119, 39)
        Me.Label110.TabIndex = 71
        Me.Label110.Text = "Bristol"
        Me.Label110.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ChooseAForm
        '
        Me.ChooseAForm.AutoSize = True
        Me.ChooseAForm.Location = New System.Drawing.Point(438, 69)
        Me.ChooseAForm.Name = "ChooseAForm"
        Me.ChooseAForm.Size = New System.Drawing.Size(95, 28)
        Me.ChooseAForm.TabIndex = 70
        Me.ChooseAForm.Text = "Choose"
        Me.ChooseAForm.UseVisualStyleBackColor = True
        '
        'Label111
        '
        Me.Label111.AutoSize = True
        Me.Label111.Location = New System.Drawing.Point(7, 69)
        Me.Label111.Name = "Label111"
        Me.Label111.Size = New System.Drawing.Size(23, 24)
        Me.Label111.TabIndex = 69
        Me.Label111.Text = "A"
        '
        'Label112
        '
        Me.Label112.AutoEllipsis = True
        Me.Label112.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label112.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label112.Location = New System.Drawing.Point(265, 65)
        Me.Label112.Name = "Label112"
        Me.Label112.Size = New System.Drawing.Size(119, 39)
        Me.Label112.TabIndex = 68
        Me.Label112.Text = "London"
        Me.Label112.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label113
        '
        Me.Label113.AutoSize = True
        Me.Label113.Location = New System.Drawing.Point(7, 257)
        Me.Label113.Name = "Label113"
        Me.Label113.Size = New System.Drawing.Size(23, 24)
        Me.Label113.TabIndex = 67
        Me.Label113.Text = "E"
        '
        'Label114
        '
        Me.Label114.AutoEllipsis = True
        Me.Label114.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label114.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label114.Location = New System.Drawing.Point(265, 253)
        Me.Label114.Name = "Label114"
        Me.Label114.Size = New System.Drawing.Size(119, 39)
        Me.Label114.TabIndex = 66
        Me.Label114.Text = "Wrexham"
        Me.Label114.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label115
        '
        Me.Label115.AutoSize = True
        Me.Label115.Location = New System.Drawing.Point(7, 210)
        Me.Label115.Name = "Label115"
        Me.Label115.Size = New System.Drawing.Size(23, 24)
        Me.Label115.TabIndex = 65
        Me.Label115.Text = "D"
        '
        'Label116
        '
        Me.Label116.AutoEllipsis = True
        Me.Label116.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label116.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label116.Location = New System.Drawing.Point(265, 206)
        Me.Label116.Name = "Label116"
        Me.Label116.Size = New System.Drawing.Size(119, 39)
        Me.Label116.TabIndex = 64
        Me.Label116.Text = "Bradford"
        Me.Label116.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label117
        '
        Me.Label117.AutoSize = True
        Me.Label117.Location = New System.Drawing.Point(7, 116)
        Me.Label117.Name = "Label117"
        Me.Label117.Size = New System.Drawing.Size(22, 24)
        Me.Label117.TabIndex = 63
        Me.Label117.Text = "B"
        '
        'Label138
        '
        Me.Label138.AutoEllipsis = True
        Me.Label138.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label138.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label138.Location = New System.Drawing.Point(265, 112)
        Me.Label138.Name = "Label138"
        Me.Label138.Size = New System.Drawing.Size(119, 39)
        Me.Label138.TabIndex = 62
        Me.Label138.Text = "Cardiff"
        Me.Label138.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.Label137)
        Me.TabPage7.Controls.Add(Me.Label118)
        Me.TabPage7.Controls.Add(Me.Label119)
        Me.TabPage7.Controls.Add(Me.Label120)
        Me.TabPage7.Controls.Add(Me.Label121)
        Me.TabPage7.Controls.Add(Me.Label122)
        Me.TabPage7.Controls.Add(Me.Label123)
        Me.TabPage7.Controls.Add(Me.Label124)
        Me.TabPage7.Controls.Add(Me.ChooseBCounty)
        Me.TabPage7.Controls.Add(Me.ChooseCCounty)
        Me.TabPage7.Controls.Add(Me.ChooseDCounty)
        Me.TabPage7.Controls.Add(Me.ChooseECounty)
        Me.TabPage7.Controls.Add(Me.ChooseFcounty)
        Me.TabPage7.Controls.Add(Me.Label125)
        Me.TabPage7.Controls.Add(Me.Label126)
        Me.TabPage7.Controls.Add(Me.Label127)
        Me.TabPage7.Controls.Add(Me.Label128)
        Me.TabPage7.Controls.Add(Me.ChooseACounty)
        Me.TabPage7.Controls.Add(Me.Label129)
        Me.TabPage7.Controls.Add(Me.Label130)
        Me.TabPage7.Controls.Add(Me.Label131)
        Me.TabPage7.Controls.Add(Me.Label132)
        Me.TabPage7.Controls.Add(Me.Label133)
        Me.TabPage7.Controls.Add(Me.Label134)
        Me.TabPage7.Controls.Add(Me.Label135)
        Me.TabPage7.Controls.Add(Me.Label136)
        Me.TabPage7.Location = New System.Drawing.Point(54, 4)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(560, 418)
        Me.TabPage7.TabIndex = 3
        Me.TabPage7.Text = "County"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'Label137
        '
        Me.Label137.AutoSize = True
        Me.Label137.Location = New System.Drawing.Point(62, 17)
        Me.Label137.Name = "Label137"
        Me.Label137.Size = New System.Drawing.Size(61, 24)
        Me.Label137.TabIndex = 61
        Me.Label137.Text = "Name"
        '
        'Label118
        '
        Me.Label118.AutoSize = True
        Me.Label118.Location = New System.Drawing.Point(289, 17)
        Me.Label118.Name = "Label118"
        Me.Label118.Size = New System.Drawing.Size(69, 24)
        Me.Label118.TabIndex = 60
        Me.Label118.Text = "County"
        '
        'Label119
        '
        Me.Label119.AutoEllipsis = True
        Me.Label119.Location = New System.Drawing.Point(46, 304)
        Me.Label119.Name = "Label119"
        Me.Label119.Size = New System.Drawing.Size(195, 31)
        Me.Label119.TabIndex = 59
        Me.Label119.Text = "SillyDogname"
        '
        'Label120
        '
        Me.Label120.AutoEllipsis = True
        Me.Label120.Location = New System.Drawing.Point(46, 257)
        Me.Label120.Name = "Label120"
        Me.Label120.Size = New System.Drawing.Size(195, 31)
        Me.Label120.TabIndex = 58
        Me.Label120.Text = "SillyDogname"
        '
        'Label121
        '
        Me.Label121.AutoEllipsis = True
        Me.Label121.Location = New System.Drawing.Point(46, 210)
        Me.Label121.Name = "Label121"
        Me.Label121.Size = New System.Drawing.Size(195, 31)
        Me.Label121.TabIndex = 57
        Me.Label121.Text = "SillyDogname"
        '
        'Label122
        '
        Me.Label122.AutoEllipsis = True
        Me.Label122.Location = New System.Drawing.Point(46, 163)
        Me.Label122.Name = "Label122"
        Me.Label122.Size = New System.Drawing.Size(195, 31)
        Me.Label122.TabIndex = 56
        Me.Label122.Text = "SillyDogname"
        '
        'Label123
        '
        Me.Label123.AutoEllipsis = True
        Me.Label123.Location = New System.Drawing.Point(46, 116)
        Me.Label123.Name = "Label123"
        Me.Label123.Size = New System.Drawing.Size(195, 31)
        Me.Label123.TabIndex = 55
        Me.Label123.Text = "SillyDogname"
        '
        'Label124
        '
        Me.Label124.AutoEllipsis = True
        Me.Label124.Location = New System.Drawing.Point(46, 69)
        Me.Label124.Name = "Label124"
        Me.Label124.Size = New System.Drawing.Size(195, 31)
        Me.Label124.TabIndex = 54
        Me.Label124.Text = "SillyDogname"
        '
        'ChooseBCounty
        '
        Me.ChooseBCounty.AutoSize = True
        Me.ChooseBCounty.Location = New System.Drawing.Point(434, 116)
        Me.ChooseBCounty.Name = "ChooseBCounty"
        Me.ChooseBCounty.Size = New System.Drawing.Size(95, 28)
        Me.ChooseBCounty.TabIndex = 53
        Me.ChooseBCounty.Text = "Choose"
        Me.ChooseBCounty.UseVisualStyleBackColor = True
        '
        'ChooseCCounty
        '
        Me.ChooseCCounty.AutoSize = True
        Me.ChooseCCounty.Location = New System.Drawing.Point(434, 163)
        Me.ChooseCCounty.Name = "ChooseCCounty"
        Me.ChooseCCounty.Size = New System.Drawing.Size(95, 28)
        Me.ChooseCCounty.TabIndex = 52
        Me.ChooseCCounty.Text = "Choose"
        Me.ChooseCCounty.UseVisualStyleBackColor = True
        '
        'ChooseDCounty
        '
        Me.ChooseDCounty.AutoSize = True
        Me.ChooseDCounty.Location = New System.Drawing.Point(434, 210)
        Me.ChooseDCounty.Name = "ChooseDCounty"
        Me.ChooseDCounty.Size = New System.Drawing.Size(95, 28)
        Me.ChooseDCounty.TabIndex = 51
        Me.ChooseDCounty.Text = "Choose"
        Me.ChooseDCounty.UseVisualStyleBackColor = True
        '
        'ChooseECounty
        '
        Me.ChooseECounty.AutoSize = True
        Me.ChooseECounty.Location = New System.Drawing.Point(434, 257)
        Me.ChooseECounty.Name = "ChooseECounty"
        Me.ChooseECounty.Size = New System.Drawing.Size(95, 28)
        Me.ChooseECounty.TabIndex = 50
        Me.ChooseECounty.Text = "Choose"
        Me.ChooseECounty.UseVisualStyleBackColor = True
        '
        'ChooseFcounty
        '
        Me.ChooseFcounty.AutoSize = True
        Me.ChooseFcounty.Location = New System.Drawing.Point(434, 304)
        Me.ChooseFcounty.Name = "ChooseFcounty"
        Me.ChooseFcounty.Size = New System.Drawing.Size(95, 28)
        Me.ChooseFcounty.TabIndex = 49
        Me.ChooseFcounty.Text = "Choose"
        Me.ChooseFcounty.UseVisualStyleBackColor = True
        '
        'Label125
        '
        Me.Label125.AutoSize = True
        Me.Label125.Location = New System.Drawing.Point(8, 304)
        Me.Label125.Name = "Label125"
        Me.Label125.Size = New System.Drawing.Size(22, 24)
        Me.Label125.TabIndex = 48
        Me.Label125.Text = "F"
        '
        'Label126
        '
        Me.Label126.AutoEllipsis = True
        Me.Label126.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label126.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label126.Location = New System.Drawing.Point(247, 300)
        Me.Label126.Name = "Label126"
        Me.Label126.Size = New System.Drawing.Size(181, 39)
        Me.Label126.TabIndex = 47
        Me.Label126.Text = "Cambridge"
        Me.Label126.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label127
        '
        Me.Label127.AutoSize = True
        Me.Label127.Location = New System.Drawing.Point(8, 163)
        Me.Label127.Name = "Label127"
        Me.Label127.Size = New System.Drawing.Size(23, 24)
        Me.Label127.TabIndex = 46
        Me.Label127.Text = "C"
        '
        'Label128
        '
        Me.Label128.AutoEllipsis = True
        Me.Label128.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label128.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label128.Location = New System.Drawing.Point(247, 159)
        Me.Label128.Name = "Label128"
        Me.Label128.Size = New System.Drawing.Size(181, 39)
        Me.Label128.TabIndex = 45
        Me.Label128.Text = "Bristol"
        Me.Label128.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ChooseACounty
        '
        Me.ChooseACounty.AutoSize = True
        Me.ChooseACounty.Location = New System.Drawing.Point(434, 69)
        Me.ChooseACounty.Name = "ChooseACounty"
        Me.ChooseACounty.Size = New System.Drawing.Size(95, 28)
        Me.ChooseACounty.TabIndex = 44
        Me.ChooseACounty.Text = "Choose"
        Me.ChooseACounty.UseVisualStyleBackColor = True
        '
        'Label129
        '
        Me.Label129.AutoSize = True
        Me.Label129.Location = New System.Drawing.Point(8, 69)
        Me.Label129.Name = "Label129"
        Me.Label129.Size = New System.Drawing.Size(23, 24)
        Me.Label129.TabIndex = 43
        Me.Label129.Text = "A"
        '
        'Label130
        '
        Me.Label130.AutoEllipsis = True
        Me.Label130.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label130.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label130.Location = New System.Drawing.Point(247, 65)
        Me.Label130.Name = "Label130"
        Me.Label130.Size = New System.Drawing.Size(181, 39)
        Me.Label130.TabIndex = 42
        Me.Label130.Text = "London"
        Me.Label130.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label131
        '
        Me.Label131.AutoSize = True
        Me.Label131.Location = New System.Drawing.Point(8, 257)
        Me.Label131.Name = "Label131"
        Me.Label131.Size = New System.Drawing.Size(23, 24)
        Me.Label131.TabIndex = 41
        Me.Label131.Text = "E"
        '
        'Label132
        '
        Me.Label132.AutoEllipsis = True
        Me.Label132.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label132.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label132.Location = New System.Drawing.Point(247, 253)
        Me.Label132.Name = "Label132"
        Me.Label132.Size = New System.Drawing.Size(181, 39)
        Me.Label132.TabIndex = 40
        Me.Label132.Text = "Wrexham"
        Me.Label132.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label133
        '
        Me.Label133.AutoSize = True
        Me.Label133.Location = New System.Drawing.Point(8, 210)
        Me.Label133.Name = "Label133"
        Me.Label133.Size = New System.Drawing.Size(23, 24)
        Me.Label133.TabIndex = 39
        Me.Label133.Text = "D"
        '
        'Label134
        '
        Me.Label134.AutoEllipsis = True
        Me.Label134.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label134.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label134.Location = New System.Drawing.Point(247, 206)
        Me.Label134.Name = "Label134"
        Me.Label134.Size = New System.Drawing.Size(181, 39)
        Me.Label134.TabIndex = 38
        Me.Label134.Text = "Bradford"
        Me.Label134.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label135
        '
        Me.Label135.AutoSize = True
        Me.Label135.Location = New System.Drawing.Point(8, 116)
        Me.Label135.Name = "Label135"
        Me.Label135.Size = New System.Drawing.Size(22, 24)
        Me.Label135.TabIndex = 37
        Me.Label135.Text = "B"
        '
        'Label136
        '
        Me.Label136.AutoEllipsis = True
        Me.Label136.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label136.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label136.Location = New System.Drawing.Point(247, 112)
        Me.Label136.Name = "Label136"
        Me.Label136.Size = New System.Drawing.Size(181, 39)
        Me.Label136.TabIndex = 36
        Me.Label136.Text = "Cardiff"
        Me.Label136.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TabControl1
        '
        Me.TabControl1.Alignment = System.Windows.Forms.TabAlignment.Left
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Controls.Add(Me.TabPage8)
        Me.TabControl1.Controls.Add(Me.TabPage9)
        Me.TabControl1.Controls.Add(Me.TabPage10)
        Me.TabControl1.Controls.Add(Me.TabPage11)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.HotTrack = True
        Me.TabControl1.ItemSize = New System.Drawing.Size(41, 50)
        Me.TabControl1.Location = New System.Drawing.Point(37, 140)
        Me.TabControl1.Multiline = True
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(618, 426)
        Me.TabControl1.TabIndex = 0
        '
        'InfoBrowseForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.DogRaceApp.My.Resources.Resources.greyhound_3
        Me.ClientSize = New System.Drawing.Size(739, 659)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.TabControl2)
        Me.Controls.Add(Me.TabControl1)
        Me.DoubleBuffered = True
        Me.Name = "InfoBrowseForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.TabPage11.ResumeLayout(False)
        Me.TabPage11.PerformLayout()
        Me.TabPage10.ResumeLayout(False)
        Me.TabPage10.PerformLayout()
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage8.PerformLayout()
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl2 As System.Windows.Forms.TabControl
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents TabPage11 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage10 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ChooseADog As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseBDog As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseCDog As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseDDog As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseEDog As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseFDog As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseACounty As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseBCounty As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseCCounty As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseDCounty As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseECounty As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseFcounty As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseAForm As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseBForm As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseCForm As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseDForm As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseEform As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseFForm As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseAAge As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseBAge As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseCAge As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseDAge As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseEAge As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseFAge As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseAWin As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseBWin As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseCWin As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseDWin As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseEWin As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseFWin As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseAPos As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseBPos As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseCPos As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseDPos As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseEPos As System.Windows.Forms.CheckBox
    Friend WithEvents ChooseFPos As System.Windows.Forms.CheckBox
    Private WithEvents AxMMCCtrl1 As AxCICLib.AxMMCCtrl
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents AgeDogPanel As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents label200 As System.Windows.Forms.Label
    Friend WithEvents CountyDogPanel As System.Windows.Forms.Label
    Friend WithEvents WinDogPanel As System.Windows.Forms.Label
    Friend WithEvents FormDogPanel As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label179 As System.Windows.Forms.Label
    Friend WithEvents Label180 As System.Windows.Forms.Label
    Friend WithEvents Label181 As System.Windows.Forms.Label
    Friend WithEvents Label182 As System.Windows.Forms.Label
    Friend WithEvents Label183 As System.Windows.Forms.Label
    Friend WithEvents Label184 As System.Windows.Forms.Label
    Friend WithEvents Label185 As System.Windows.Forms.Label
    Friend WithEvents Label139 As System.Windows.Forms.Label
    Friend WithEvents Label140 As System.Windows.Forms.Label
    Friend WithEvents Label141 As System.Windows.Forms.Label
    Friend WithEvents Label142 As System.Windows.Forms.Label
    Friend WithEvents Label143 As System.Windows.Forms.Label
    Friend WithEvents Label144 As System.Windows.Forms.Label
    Friend WithEvents Label145 As System.Windows.Forms.Label
    Friend WithEvents Label146 As System.Windows.Forms.Label
    Friend WithEvents Label147 As System.Windows.Forms.Label
    Friend WithEvents Label148 As System.Windows.Forms.Label
    Friend WithEvents Label149 As System.Windows.Forms.Label
    Friend WithEvents Label150 As System.Windows.Forms.Label
    Friend WithEvents Label151 As System.Windows.Forms.Label
    Friend WithEvents Label152 As System.Windows.Forms.Label
    Friend WithEvents Label153 As System.Windows.Forms.Label
    Friend WithEvents Label154 As System.Windows.Forms.Label
    Friend WithEvents Label155 As System.Windows.Forms.Label
    Friend WithEvents Label156 As System.Windows.Forms.Label
    Friend WithEvents Label157 As System.Windows.Forms.Label
    Friend WithEvents Label158 As System.Windows.Forms.Label
    Friend WithEvents Label159 As System.Windows.Forms.Label
    Friend WithEvents Label160 As System.Windows.Forms.Label
    Friend WithEvents Label161 As System.Windows.Forms.Label
    Friend WithEvents Label162 As System.Windows.Forms.Label
    Friend WithEvents Label163 As System.Windows.Forms.Label
    Friend WithEvents Label164 As System.Windows.Forms.Label
    Friend WithEvents Label165 As System.Windows.Forms.Label
    Friend WithEvents Label166 As System.Windows.Forms.Label
    Friend WithEvents Label167 As System.Windows.Forms.Label
    Friend WithEvents Label168 As System.Windows.Forms.Label
    Friend WithEvents Label169 As System.Windows.Forms.Label
    Friend WithEvents Label170 As System.Windows.Forms.Label
    Friend WithEvents Label171 As System.Windows.Forms.Label
    Friend WithEvents Label172 As System.Windows.Forms.Label
    Friend WithEvents Label173 As System.Windows.Forms.Label
    Friend WithEvents Label174 As System.Windows.Forms.Label
    Friend WithEvents Label175 As System.Windows.Forms.Label
    Friend WithEvents Label176 As System.Windows.Forms.Label
    Friend WithEvents Label177 As System.Windows.Forms.Label
    Friend WithEvents Label178 As System.Windows.Forms.Label
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label99 As System.Windows.Forms.Label
    Friend WithEvents Label100 As System.Windows.Forms.Label
    Friend WithEvents Label101 As System.Windows.Forms.Label
    Friend WithEvents Label102 As System.Windows.Forms.Label
    Friend WithEvents Label103 As System.Windows.Forms.Label
    Friend WithEvents Label104 As System.Windows.Forms.Label
    Friend WithEvents Label105 As System.Windows.Forms.Label
    Friend WithEvents Label106 As System.Windows.Forms.Label
    Friend WithEvents Label107 As System.Windows.Forms.Label
    Friend WithEvents Label108 As System.Windows.Forms.Label
    Friend WithEvents Label109 As System.Windows.Forms.Label
    Friend WithEvents Label110 As System.Windows.Forms.Label
    Friend WithEvents Label111 As System.Windows.Forms.Label
    Friend WithEvents Label112 As System.Windows.Forms.Label
    Friend WithEvents Label113 As System.Windows.Forms.Label
    Friend WithEvents Label114 As System.Windows.Forms.Label
    Friend WithEvents Label115 As System.Windows.Forms.Label
    Friend WithEvents Label116 As System.Windows.Forms.Label
    Friend WithEvents Label117 As System.Windows.Forms.Label
    Friend WithEvents Label138 As System.Windows.Forms.Label
    Friend WithEvents Label137 As System.Windows.Forms.Label
    Friend WithEvents Label118 As System.Windows.Forms.Label
    Friend WithEvents Label119 As System.Windows.Forms.Label
    Friend WithEvents Label120 As System.Windows.Forms.Label
    Friend WithEvents Label121 As System.Windows.Forms.Label
    Friend WithEvents Label122 As System.Windows.Forms.Label
    Friend WithEvents Label123 As System.Windows.Forms.Label
    Friend WithEvents Label124 As System.Windows.Forms.Label
    Friend WithEvents Label125 As System.Windows.Forms.Label
    Friend WithEvents Label126 As System.Windows.Forms.Label
    Friend WithEvents Label127 As System.Windows.Forms.Label
    Friend WithEvents Label128 As System.Windows.Forms.Label
    Friend WithEvents Label129 As System.Windows.Forms.Label
    Friend WithEvents Label130 As System.Windows.Forms.Label
    Friend WithEvents Label131 As System.Windows.Forms.Label
    Friend WithEvents Label132 As System.Windows.Forms.Label
    Friend WithEvents Label133 As System.Windows.Forms.Label
    Friend WithEvents Label134 As System.Windows.Forms.Label
    Friend WithEvents Label135 As System.Windows.Forms.Label
    Friend WithEvents Label136 As System.Windows.Forms.Label

End Class
