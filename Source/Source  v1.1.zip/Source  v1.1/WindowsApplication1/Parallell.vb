﻿Option Explicit On
Public Module parallel

    Public Declare Function Inp Lib "inpout32.dll" _
    Alias "Inp32" (ByVal PortAddress As Integer) As Integer
    Public Declare Sub Out Lib "inpout32.dll" _
    Alias "Out32" (ByVal PortAddress As Integer, ByVal Value As Integer)
    Private currentState As Byte

    'Simple parallel port (LTP) output
    'Modified for using the 'inpout32' library

    'Modified Nov '09 to keep internal copy of line states
    'Rather than relying on the Inp() function to obtain states

    Public Const PARALLEL_OUTPUT_ADDRESS As Integer = &H378

    Public Const Line0 As Byte = 1
    Public Const Line1 As Byte = 2
    Public Const Line2 As Byte = 4
    Public Const Line3 As Byte = 8
    Public Const Line4 As Byte = 16
    Public Const Line5 As Byte = 32
    Public Const Line6 As Byte = 64
    Public Const Line7 As Byte = 128


    Public Sub InitParallel()
        Try
            Call Out(PARALLEL_OUTPUT_ADDRESS + 2, 0) 'Control Port
            LinesOff()
        Catch
        End Try
    End Sub

    Public Sub SetLineState(ByVal Lines As Byte)
        Try
            currentState = Lines
            Call Out(PARALLEL_OUTPUT_ADDRESS, Lines)
        Catch
        End Try
    End Sub

    Public Sub LinesOff()
        Try
            currentState = 0
            Call Out(PARALLEL_OUTPUT_ADDRESS, 0)
        Catch
        End Try
    End Sub

    Public Sub AdjustLinesOn(ByVal LinesToOn As Byte, ByVal LinesToOff As Byte)
        Try
            currentState = currentState And Not (LinesToOff)
            currentState = currentState Or LinesToOn
            Call Out(PARALLEL_OUTPUT_ADDRESS, currentState)
        Catch
        End Try
    End Sub

End Module

