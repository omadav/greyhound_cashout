﻿Public Class InfoBrowseForm
    Public Enum panels
        dogA = 1
        dogb
        dogc
        dogd
        doge
        dogf
        county
        recentform
        age
        win
        avpos
        count = 11
    End Enum


    'to do this properly: a list of labels and checkboxes in array, by dog.

    Private dognames(maxdogs) As List(Of Label)
    Private countynames(maxdogs) As List(Of Label)
    Private ages(maxdogs) As List(Of Label)
    Private winpercent(maxdogs) As List(Of Label)
    Private recentform(maxdogs) As List(Of Label)
    Private avPos(maxdogs) As List(Of Label)
    'Private trialset As TrialSet
    Private curentbrowsestarttime As Date
    Private currentbrowsepanelname As String

    Public chosenDog As Integer
    Public chosenPanel As String
    Public browsetimes(panels.count) As Double
    Public tabclicks(panels.count) As Integer


    Private Sub Tab_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabControl1.Click, TabControl2.Click
        Dim j As TabControl
        j = sender
        j.BringToFront()
        With j.SelectedTab
            If Me.currentbrowsepanelname = .Name Then Exit Sub
            'Clicked on a new tab - update click count, and record of browsing.
            'to lazy to use substring -> int
            For i As Integer = 1 To panels.count
                Dim s As String = "TabPage" & i
                If .Name = s Then
                    Me.tabclicks(i) += 1 ' add a click to the CLICKED item
                    Exit For
                End If
            Next
            RecordBrowseDuration()
            Me.currentbrowsepanelname = .Name
        End With
    End Sub

    'Records length of time the tab panel has been shown
    'called when a new tab is clicked, or when the choice is confirmed
    Private Sub RecordBrowseDuration()
        If Not (curentbrowsestarttime = Nothing) Then
            For i As Integer = 1 To panels.count
                Dim s As String = "TabPage" & i
                If s = Me.currentbrowsepanelname Then
                    Dim ts As New TimeSpan
                    ts = (Now - curentbrowsestarttime)
                    browsetimes(i) += ts.TotalSeconds
                    Exit For
                End If
            Next
        End If
        curentbrowsestarttime = Now
    End Sub

    Public Function DecodeTabName(ByVal index As Integer) As String
        Select Case index
            Case 1 : Return Me.TabPage1.Text
            Case 2 : Return Me.TabPage2.Text
            Case 3 : Return Me.TabPage3.Text
            Case 4 : Return Me.TabPage4.Text
            Case 5 : Return Me.TabPage5.Text
            Case 6 : Return Me.TabPage6.Text
            Case 7 : Return Me.TabPage7.Text
            Case 8 : Return Me.TabPage8.Text
            Case 9 : Return Me.TabPage9.Text
            Case 10 : Return Me.TabPage10.Text
            Case 11 : Return Me.TabPage11.Text
            Case Else : Return ""
        End Select
    End Function

    'Public Sub New(ByRef t As TrialSet)
    '    ' This call is required by the Windows Form Designer.
    '    InitializeComponent()

    '    'would be a more readable format. Todo later.
    '    '    dognames(0).Add(label200) : dognames(0).Add(Label73) : dognames(0).Add(Label106) : dognames(0).Add(Label124) : dognames(0).Add(Label146): dognames(0).Add(Label166)
    '    '    dognames(1).Add(Label10) : dognames(1).Add(Label74) : dognames(0).Add(Label106) : dognames(0).Add(Label124) : dognames(0).Add(Label146) : dognames(0).Add(Label166)
    '    '    dognames(2).Add(label200) : dognames(0).Add(Label73) : dognames(0).Add(Label106) : dognames(0).Add(Label124) : dognames(0).Add(Label146) : dognames(0).Add(Label166)
    '    '    dognames(3).Add(label200) : dognames(0).Add(Label73) : dognames(0).Add(Label106) : dognames(0).Add(Label124) : dognames(0).Add(Label146) : dognames(0).Add(Label166)
    '    '    dognames(4).Add(label200) : dognames(0).Add(Label73) : dognames(0).Add(Label106) : dognames(0).Add(Label124) : dognames(0).Add(Label146) : dognames(0).Add(Label166)
    '    '    dognames(5).Add(label200) : dognames(0).Add(Label73) : dognames(0).Add(Label106) : dognames(0).Add(Label124) : dognames(0).Add(Label146) : dognames(0).Add(Label166)

    '    '    'etc/
    '    'Private dognames(maxdogs) As Label = {
    '    '    Private countynames(maxdogs) As Label
    '    '    Private ages(maxdogs) As Label
    '    '    Private winpercent(maxdogs) As Label
    '    '    Private recentform(maxdogs) As Label
    '    '    Private avPos(maxdogs) As Label
    '    '    ' Add any initialization after the InitializeComponent() call.

    'End Sub
    Public Sub StartBrowse(ByRef r As raceinfo.RaceData)
        Me.Button1.Enabled = False
        Me.currentbrowsepanelname = Nothing
        Me.curentbrowsestarttime = Now
        Me.TabControl1.SendToBack()
        Me.TabControl2.SendToBack()
        Call TrialSet.Psychophys_marker(trialstages.browse) ' turn on "browse" marker (if required)
        'dognames(0).Add(label200)

        label200.Text = r.Dogs(0).name
        Label73.Text = r.Dogs(0).name
        Label106.Text = r.Dogs(0).name
        Label124.Text = r.Dogs(0).name
        Label146.Text = r.Dogs(0).name
        Label166.Text = r.Dogs(0).name

        Label10.Text = r.Dogs(1).name
        Label74.Text = r.Dogs(1).name
        Label105.Text = r.Dogs(1).name
        Label123.Text = r.Dogs(1).name
        Label145.Text = r.Dogs(1).name
        Label165.Text = r.Dogs(1).name
        Label22.Text = r.Dogs(2).name
        Label75.Text = r.Dogs(2).name
        Label104.Text = r.Dogs(2).name
        Label122.Text = r.Dogs(2).name
        Label144.Text = r.Dogs(2).name
        Label164.Text = r.Dogs(2).name
        Label34.Text = r.Dogs(3).name
        Label76.Text = r.Dogs(3).name
        Label103.Text = r.Dogs(3).name
        Label121.Text = r.Dogs(3).name
        Label143.Text = r.Dogs(3).name
        Label163.Text = r.Dogs(3).name
        Label46.Text = r.Dogs(4).name
        Label77.Text = r.Dogs(4).name
        Label102.Text = r.Dogs(4).name
        Label120.Text = r.Dogs(4).name
        Label142.Text = r.Dogs(4).name
        Label162.Text = r.Dogs(4).name
        Label44.Text = r.Dogs(4).avPos
        Label154.Text = r.Dogs(4).avPos
        Label48.Text = r.Dogs(4).WinPercent
        Label174.Text = r.Dogs(4).WinPercent
        Label114.Text = r.Dogs(4).RecentForm
        Label47.Text = r.Dogs(4).County
        Label132.Text = r.Dogs(4).County
        Label55.Text = r.Dogs(4).Age
        Label66.Text = r.Dogs(4).Age
        Label49.Text = r.Dogs(4).RecentForm
        Label58.Text = r.Dogs(5).name
        Label78.Text = r.Dogs(5).name
        Label101.Text = r.Dogs(5).name
        Label119.Text = r.Dogs(5).name
        Label141.Text = r.Dogs(5).name
        Label161.Text = r.Dogs(5).name
        Label179.Text = r.Dogs(5).RecentForm
        Label72.Text = r.Dogs(5).Age
        Label185.Text = r.Dogs(5).Age
        Label126.Text = r.Dogs(5).County
        Label59.Text = r.Dogs(5).County
        Label108.Text = r.Dogs(5).RecentForm
        Label168.Text = r.Dogs(5).WinPercent
        Label60.Text = r.Dogs(5).WinPercent
        Label148.Text = r.Dogs(5).avPos
        Label56.Text = r.Dogs(5).avPos
        Label68.Text = r.Dogs(0).Age
        Label62.Text = r.Dogs(1).Age
        Label70.Text = r.Dogs(2).Age
        Label64.Text = r.Dogs(3).Age

        AgeDogPanel.Text = r.Dogs(0).Age
        Label19.Text = r.Dogs(1).Age
        Label31.Text = r.Dogs(2).Age
        Label43.Text = r.Dogs(3).Age
        Label130.Text = r.Dogs(0).County
        Label136.Text = r.Dogs(1).County
        Label128.Text = r.Dogs(2).County
        Label134.Text = r.Dogs(3).County

        CountyDogPanel.Text = r.Dogs(0).County
        Label11.Text = r.Dogs(1).County
        Label23.Text = r.Dogs(2).County
        Label35.Text = r.Dogs(3).County
        Label112.Text = r.Dogs(0).RecentForm
        Label138.Text = r.Dogs(1).RecentForm
        Label110.Text = r.Dogs(2).RecentForm
        Label116.Text = r.Dogs(3).RecentForm

        FormDogPanel.Text = r.Dogs(0).RecentForm
        Label13.Text = r.Dogs(1).RecentForm
        Label25.Text = r.Dogs(2).RecentForm
        Label37.Text = r.Dogs(3).RecentForm
        Label172.Text = r.Dogs(0).WinPercent
        Label178.Text = r.Dogs(1).WinPercent
        Label170.Text = r.Dogs(2).WinPercent
        Label176.Text = r.Dogs(3).WinPercent
        WinDogPanel.Text = r.Dogs(0).WinPercent
        Label12.Text = r.Dogs(1).WinPercent
        Label24.Text = r.Dogs(2).WinPercent
        Label36.Text = r.Dogs(3).WinPercent
        Label152.Text = r.Dogs(0).avPos
        Label158.Text = r.Dogs(1).avPos
        Label150.Text = r.Dogs(2).avPos
        Label156.Text = r.Dogs(3).avPos

        Label1.Text = r.Dogs(0).avPos
        Label8.Text = r.Dogs(1).avPos
        Label20.Text = r.Dogs(2).avPos
        Label32.Text = r.Dogs(3).avPos
        If r.nDogs < 6 Then

            ChooseFDog.Enabled = False
            ChooseFPos.Enabled = False
            ChooseFAge.Enabled = False
            ChooseFcounty.Enabled = False
            ChooseFForm.Enabled = False
            ChooseFWin.Enabled = False
            If r.nDogs < 5 Then

                ChooseEDog.Enabled = False
                ChooseEPos.Enabled = False
                ChooseEAge.Enabled = False
                ChooseECounty.Enabled = False
                ChooseEform.Enabled = False
                ChooseEWin.Enabled = False
            End If

        End If
    End Sub

    Private Sub CheckBoxes(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _
                ChooseADog.Click, ChooseBDog.Click, ChooseCDog.Click, ChooseDDog.Click, ChooseEDog.Click, ChooseFDog.Click, ChooseFAge.Click, ChooseDAge.Click, ChooseEAge.Click, ChooseAAge.Click, ChooseCAge.Click, ChooseBAge.Click, ChooseBForm.Click, ChooseCForm.Click, ChooseDForm.Click, ChooseEform.Click, ChooseFForm.Click, ChooseAForm.Click, ChooseBCounty.Click, ChooseCCounty.Click, ChooseDCounty.Click, ChooseECounty.Click, ChooseFcounty.Click, ChooseACounty.Click, ChooseBPos.Click, ChooseCPos.Click, ChooseDPos.Click, ChooseEPos.Click, ChooseFPos.Click, ChooseAPos.Click, ChooseBWin.Click, ChooseCWin.Click, ChooseDWin.Click, ChooseEWin.Click, ChooseFWin.Click, ChooseAWin.Click
        Dim choice = CType(sender, CheckBox).Name
        If Not (choice Like "Choose*") Then
            Debug.Print("Error in retreiving chkbox name")
        End If
        Dim dog As Char = choice.Substring("choose".Length, 1)
        Dim panel As String = choice.Substring("choosea".Length)

        setcheckboxes(dog)
        Me.chosenPanel = panel
        'Select Case LCase(panel)
        '    Case "dog"
        '        Select Case UCase(dog)
        '            Case "A" : Me.chosenPanel = panels.dogA
        '            Case "B" : Me.chosenPanel = panels.dogb
        '            Case "C" : Me.chosenPanel = panels.dogc
        '            Case "D" : Me.chosenPanel = panels.dogd
        '            Case "E" : Me.chosenPanel = panels.doge
        '            Case "F" : Me.chosenPanel = panels.dogf
        '        End Select
        '    Case "pos" : Me.chosenPanel = panels.avpos
        '    Case "age" : Me.chosenPanel = panels.age
        '    Case "county" : Me.chosenPanel = panels.county
        '    Case "form" : Me.chosenPanel = panels.recentform
        '    Case "win" : Me.chosenPanel = panels.win
        '    Case Else : MsgBox("bugger - panel not decoded")
        'End Select
        Me.Button1.Enabled = True
    End Sub
    Private Sub setcheckboxes(ByVal dog As Char)
        'again. would be better with lists. Live with this for now.
        ChooseADog.Checked = False
        ChooseAPos.Checked = False
        ChooseAAge.Checked = False
        ChooseACounty.Checked = False
        ChooseAForm.Checked = False
        ChooseAWin.Checked = False
        ChooseBDog.Checked = False
        ChooseBPos.Checked = False
        ChooseBAge.Checked = False
        ChooseBCounty.Checked = False
        ChooseBForm.Checked = False
        ChooseBWin.Checked = False
        ChooseCDog.Checked = False
        ChooseCPos.Checked = False
        ChooseCAge.Checked = False
        ChooseCCounty.Checked = False
        ChooseCForm.Checked = False
        ChooseCWin.Checked = False
        ChooseDDog.Checked = False
        ChooseDPos.Checked = False
        ChooseDAge.Checked = False
        ChooseDCounty.Checked = False
        ChooseDForm.Checked = False
        ChooseDWin.Checked = False
        ChooseEDog.Checked = False
        ChooseEPos.Checked = False
        ChooseEAge.Checked = False
        ChooseECounty.Checked = False
        ChooseEform.Checked = False
        ChooseEWin.Checked = False
        ChooseFDog.Checked = False
        ChooseFPos.Checked = False
        ChooseFAge.Checked = False
        ChooseFcounty.Checked = False
        ChooseFForm.Checked = False
        ChooseFWin.Checked = False

        Select Case UCase(dog)
            Case "A"
                ChooseADog.Checked = True
                ChooseAPos.Checked = True
                ChooseAAge.Checked = True
                ChooseACounty.Checked = True
                ChooseAForm.Checked = True
                ChooseAWin.Checked = True
                Me.chosenDog = 1
            Case "B"
                ChooseBDog.Checked = True
                ChooseBPos.Checked = True
                ChooseBAge.Checked = True
                ChooseBCounty.Checked = True
                ChooseBForm.Checked = True
                ChooseBWin.Checked = True
                Me.chosenDog = 2
            Case "C"
                ChooseCDog.Checked = True
                ChooseCPos.Checked = True
                ChooseCAge.Checked = True
                ChooseCCounty.Checked = True
                ChooseCForm.Checked = True
                ChooseCWin.Checked = True
                Me.chosenDog = 3
            Case "D"
                ChooseDDog.Checked = True
                ChooseDPos.Checked = True
                ChooseDAge.Checked = True
                ChooseDCounty.Checked = True
                ChooseDForm.Checked = True
                ChooseDWin.Checked = True
                Me.chosenDog = 4
            Case "E"
                ChooseEDog.Checked = True
                ChooseEPos.Checked = True
                ChooseEAge.Checked = True
                ChooseECounty.Checked = True
                ChooseEform.Checked = True
                ChooseEWin.Checked = True
                Me.chosenDog = 5
            Case "F"
                ChooseFDog.Checked = True
                ChooseFPos.Checked = True
                ChooseFAge.Checked = True
                ChooseFcounty.Checked = True
                ChooseFForm.Checked = True
                ChooseFWin.Checked = True
                Me.chosenDog = 6
        End Select

    End Sub


    Private Sub Confirm(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.RecordBrowseDuration()
        Me.Close()
    End Sub


    Private Sub Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panel1.Paint

    End Sub
End Class