﻿
Imports System.Collections
Public Enum trialstages As Integer
    'used for psychophys markers
    trialstart
    browse
    rating1
    draws
    race
    score
    rating2
    over
End Enum
Public Class TrialSet
    Public Shared Delimiters() As String = {","}
    Public races As New List(Of raceinfo.RaceData)

    Public Sub New(ByVal f As String)
        Dim FileReader As New  _
            Microsoft.VisualBasic.FileIO.TextFieldParser(f)
        Dim race As raceinfo.RaceData
        Dim dog As Integer
        Dim currentRow As String()
        With FileReader
            .SetDelimiters(Delimiters)
            While Not .EndOfData
                Try
                    currentRow = .ReadFields()
                    If currentRow(0) Like "RACE*" Then
                        race = New raceinfo.RaceData(currentRow)
                        races.Add(race)
                        dog = 0
                    End If

                    If currentRow(0) Like "DOG*" Then
                        If Not (race Is Nothing) Then
                            If dog <= race.nDogs Then
                                race.Dogs(dog) = New DogInfo(currentRow)
                                dog += 1
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
            End While
        End With
    End Sub
    Public Shared Sub Psychophys_marker(ByVal stage As trialstages)
        'import the parallel library
        Select Case stage
            Case trialstages.trialstart : parallel.SetLineState(parallel.Line0)
            Case trialstages.browse : parallel.SetLineState(parallel.Line1 + parallel.Line0)
            Case trialstages.rating1 : parallel.SetLineState(parallel.Line0)
            Case trialstages.draws : parallel.SetLineState(parallel.Line2 + parallel.Line0)
            Case trialstages.race : parallel.SetLineState(parallel.Line3 + parallel.Line0)
            Case trialstages.score : parallel.SetLineState(parallel.Line4 + parallel.Line0)
            Case trialstages.rating2 : parallel.SetLineState(parallel.Line0)
            Case trialstages.over : parallel.LinesOff()
        End Select
    End Sub
    Public Sub RunTrials()
        'protocol.... [** => psychophys mark]
        '1. Show the race number
        '2. **let them browse the info (record where choice is made)
        '3. switch chosen and forced trap numbers
        '4. reveal trap draws
        '5. collect a pre-race rating
        '6. **show race
        '7. collect post-race rating
        '8. show cumulative score
        Dim race As raceinfo.RaceData
        For irace As Integer = 0 To races.Count - 1
            race = races(irace)

            Using ra As New NextRaceDlg(My.Settings.raceAnnounceDelay, races.Count)
                ra.announcerace(irace + 1)
            End Using

            With race
                Using f As New InfoBrowseForm()
                    '1 TODO start of trial stuff. Could be done on BrowseInfoForm if we supply the trialnumber.
                    Call Psychophys_marker(trialstages.trialstart)
                    '2 browse & click
                    f.StartBrowse(race)
                    Do
                        f.ShowDialog()
                    Loop Until f.chosenDog > 0
                    .ChosenDog = f.chosenDog - 1
                    .data_chosepanel = f.chosenPanel
                    .data_browsetimes = f.browsetimes
                    .data_tabclicks = f.tabclicks

                    '3 collect rating
                    If My.Settings.preracerating Then
                        Call Psychophys_marker(trialstages.rating1)
                        Using rf As New RatingForm(My.Settings.RatingQ1, My.Settings.Anchor1, My.Settings.Anchor2)
                            rf.ShowDialog()
                            .data_rating1 = rf.ProgressBar1.Value
                        End Using
                    End If

                    '4  generate trap draws
                    .assigntrapnumbers(.ChosenDog)
                    Dim n(6) As String
                    For i As Integer = 1 To 6 ' traps are numbered 1-6
                        For j As Integer = 0 To 5
                            If .Dogs(j).trap = i Then
                                n(i) = .Dogs(j).name
                                Exit For
                            End If
                        Next
                    Next
                    
                    '5 show trap
                    Psychophys_marker(trialstages.draws)
                    Using df As New DrawDlg(My.Settings.DrawDelay, .DogTheyBetOnGoesIn, n)
                        df.ShowDialog()
                    End Using
                    '6 - Race()
                    Using r As New RaceVideo
                        Psychophys_marker(trialstages.race)
                        r.AxWindowsMediaPlayer1.URL = .VideoFileName
                        r.ShowDialog()
                    End Using
                    '7 - feedback etc.
                    Call Psychophys_marker(trialstages.score)
                    Using res As New ResultDlg(.DogTheyBetOnGoesIn, n(.TrueResultPlaces(0)), n(.TrueResultPlaces(1)), n(.TrueResultPlaces(2)), _
                                             .TrueResultPlaces(0), .TrueResultPlaces(1), .TrueResultPlaces(2), _
                                             .Dogs(.ChosenDog).name)
                        res.ShowDialog()
                    End Using
                    '8 - post race rating(s)
                    Call Psychophys_marker(trialstages.rating2)
                    If My.Settings.postracerating Then
                        Using rf2 As New RatingForm(My.Settings.RatingQ2, My.Settings.Anchor3, My.Settings.Anchor4)
                            rf2.ShowDialog()
                            .data_rating2 = rf2.ProgressBar1.Value
                        End Using
                    End If
                    If My.Settings.postracerating2 Then
                        Using rf3 As New RatingForm(My.Settings.RatingQ3, My.Settings.Anchor5, My.Settings.Anchor6)
                            rf3.ShowDialog()
                            .data_rating3 = rf3.ProgressBar1.Value
                        End Using
                    End If
                    Call Psychophys_marker(trialstages.over)

                End Using
            End With
        Next
    End Sub

End Class
