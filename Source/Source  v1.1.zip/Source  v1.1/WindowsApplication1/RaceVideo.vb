﻿Public Class RaceVideo
    Private Sub AxWindowsMediaPlayer1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Public Sub Play()
        With AxWindowsMediaPlayer1
            .BringToFront()
            .Visible = True
            .Ctlcontrols.play()
        End With
    End Sub

    Private Sub AxWindowsMediaPlayer1_PlayStateChange(ByVal sender As Object, ByVal e As AxWMPLib._WMPOCXEvents_PlayStateChangeEvent) Handles AxWindowsMediaPlayer1.PlayStateChange
        If AxWindowsMediaPlayer1.playState = WMPLib.WMPPlayState.wmppsMediaEnded Then
            Me.Close()
        End If
    End Sub

 
    Private Sub AxWindowsMediaPlayer1_Enter_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AxWindowsMediaPlayer1.Enter

    End Sub

    Private Sub RaceVideo_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Me.Play()
    End Sub

    Public Sub setVideo(ByVal filename As String)
        Me.AxWindowsMediaPlayer1.URL = filename
    End Sub
End Class