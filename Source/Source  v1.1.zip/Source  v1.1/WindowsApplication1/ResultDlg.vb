﻿Imports System.Windows.Forms

Public Class ResultDlg
    Public Sub New(ByVal selected As TrapNumber, ByVal Name1 As String, ByVal Name2 As String, ByVal Name3 As String, ByVal Won As TrapNumber, ByVal second As TrapNumber, ByVal Third As TrapNumber, Optional ByVal DogName As String = "Error - no name")
        InitializeComponent()
        Me.Label1.Text = Name1
        Me.Label2.Text = Name2
        Me.Label3.Text = Name3
        Me.PictureBox1.BackgroundImage = raceinfo.imagefromtrapnumber(Won)
        Me.PictureBox2.BackgroundImage = raceinfo.imagefromtrapnumber(second)
        Me.PictureBox3.BackgroundImage = raceinfo.imagefromtrapnumber(Third)
        Select Case selected
            Case Won : Me.Label1.Font = Me.Label7.Font : Me.DogLabel.Text = Name1 : Me.OutcomeLabel.Text = "won!"
            Case second : Me.Label2.Font = Me.Label7.Font : Me.DogLabel.Text = Name2 : Me.OutcomeLabel.Text = "came second."
            Case Third : Me.Label3.Font = Me.Label7.Font : Me.DogLabel.Text = Name3 : Me.OutcomeLabel.Text = "came third."
            Case Else : Me.DogLabel.Text = DogName : Me.OutcomeLabel.Text = "did not place."
        End Select
    End Sub

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Me.OK_Button.Visible = True
    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub ResultDlg_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
