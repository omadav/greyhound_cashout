﻿Option Explicit On
Public Class Start
    '##############
    '~~~MAIN FORM
    '############
    Public Shared bExit As Boolean


    Dim m_opFile As System.IO.StreamWriter, _
        bSaved As Boolean = False, _
        t As TrialSet

    Private Sub SelectDataPressed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        With Me.SaveFileDialog1
            .ValidateNames = True
            .Title = "Select Data File"
            .FileName = Trim(Me.TextBox1.Text) & "_" & Trim(Me.TextBox2.Text) & "DogRaceData.csv"
            .OverwritePrompt = True
            .InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        End With
        Me.SaveFileDialog1.ShowDialog()
        Try
            m_opFile = New System.IO.StreamWriter(Me.SaveFileDialog1.OpenFile())
        Catch ex As Exception
            m_opFile = Nothing
            MsgBox("Failed to open file " & vbNewLine & "[" & ex.Message & "]")
            Me.Button1.Visible = False
            Exit Sub
        End Try
        Me.Button1.Visible = True
    End Sub

    Private Sub CheckSave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.FormClosing
        If Not bSaved Then savedata()
    End Sub

    Private Sub RunTrials(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Become the background
        Me.Bounds = My.Computer.Screen.Bounds
        Me.BackColor = Color.Black
        For Each c As Control In Me.Controls
            c.Visible = False
        Next
        t = New TrialSet(Me.OpenFileDialog1.FileName)
        t.RunTrials()
        savedata()
    End Sub
    Private Sub savedata()
        Dim ex As Exception
        Try
            m_opFile.WriteLine(Me.ProductName & " v" & Me.ProductVersion)
            m_opFile.WriteLine("Run at " & Now.ToShortTimeString & " on " & Now.ToShortDateString)
            m_opFile.WriteLine()
            m_opFile.WriteLine(RaceData.dataHeader)
            For Each rd As RaceData In t.races
                Try
                    rd.SaveData(m_opFile)
                    m_opFile.WriteLine()
                Catch ex
                End Try
            Next
            m_opFile.WriteLine()
            m_opFile.WriteLine("Settings:")
            Dim r As System.Configuration.SettingsProperty
            For Each r In My.Settings.Properties
                Try
                    m_opFile.WriteLine(r.Name & " : " & My.Settings.Item(r.Name).ToString)
                Catch ex
                End Try
            Next
            MsgBox("Data saved")
            bSaved = True
            If ex Is Nothing Then
            Else
                MsgBox("Error while data saving: " & ex.Message)
            End If
        Catch ex
            MsgBox("Error prevented data saving: " & ex.Message)
        End Try
        m_opFile.Flush()
        Application.Exit()
        bExit = True
        Exit Sub
    End Sub

    
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        With Me.OpenFileDialog1
            If .ShowDialog() = Windows.Forms.DialogResult.OK Then
                Try
                    t = New TrialSet(.FileName)
                    Me.Button2.Enabled = True
                Catch ex As Exception
                    MsgBox("Failed to load configuration: " & vbNewLine & ex.Message, MsgBoxStyle.OkOnly, "Load error")
                End Try

            End If

        End With
    End Sub

    Private Sub OpenFileDialog1_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk

    End Sub

    Private Sub Start_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub SaveFileDialog1_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles SaveFileDialog1.FileOk

    End Sub
End Class