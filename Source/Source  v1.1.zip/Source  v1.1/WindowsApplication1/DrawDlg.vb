﻿Imports System.Windows.Forms

Public Class DrawDlg

    Public Sub New(ByVal delaytoOK As Integer, ByVal selected As Integer, ByRef name() As String)
        InitializeComponent()
        Me.Timer1.Interval = delaytoOK
        Me.Timer1.Enabled = False
        Me.Trap1.Text = name(1)
        Me.Trap2.Text = name(2)
        Me.Trap3.Text = name(3)
        Me.Trap4.Text = name(4)
        Me.Trap5.Text = name(5)
        Me.Trap6.Text = name(6)
        Select Case selected
            Case 1 : Me.Trap1.Font = Me.Label7.Font : Me.Trap1.ForeColor = Color.Black
            Case 2 : Me.Trap2.Font = Me.Label7.Font : Me.Trap2.ForeColor = Color.Black
            Case 3 : Me.Trap3.Font = Me.Label7.Font : Me.Trap3.ForeColor = Color.Black
            Case 4 : Me.Trap4.Font = Me.Label7.Font : Me.Trap4.ForeColor = Color.Black
            Case 5 : Me.Trap5.Font = Me.Label7.Font : Me.Trap5.ForeColor = Color.Black
            Case 6 : Me.Trap6.Font = Me.Label7.Font : Me.Trap6.ForeColor = Color.Black
        End Select
    End Sub

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Me.OK_Button.Visible = True
    End Sub

    Private Sub DrawDlg_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub DrawDlg_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Me.Timer1.Enabled = True
    End Sub
End Class
