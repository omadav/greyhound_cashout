﻿Public Module raceinfo
    Public Const maxdogs = 6
    Public Enum TrapNumber
        empty = 0
        one = 1
        two
        three
        four
        five
        six
    End Enum

    Function imagefromtrapnumber(ByVal Trap As TrapNumber) As Bitmap
        Select Case Trap
            Case 1 : Return My.Resources.Trap1
            Case 2 : Return My.Resources.Trap2
            Case 3 : Return My.Resources.Trap3
            Case 4 : Return My.Resources.Trap4
            Case 5 : Return My.Resources.Trap5
            Case Else : Return My.Resources.Trap6
        End Select
    End Function

    Public Class RaceData
        Public Enum fields
            raceid = 1
            result123
            nDogs
            ForceTrap
            OutcomeType
            VideoFileName
        End Enum

        Public raceID As String
        Public VideoFileName As String 'System.IO.Path
        Public TrueResultPlaces(0 To 2) As TrapNumber
        Public DogTheyBetOnGoesIn As TrapNumber
        Public ChosenDog As Integer 'zero based
        Public nDogs As Integer
        Public outcometype As String

        Public data_browsetimes() As Double
        Public data_tabclicks() As Integer
        Public data_chosepanel As String
        Public data_rating1 As Integer
        Public data_rating2 As Integer
        Public data_rating3 As Integer

        Public Dogs(0 To 5) As DogInfo

        Public Sub assigntrapnumbers(ByVal chosendog As Integer)
            'put any dogs without traps (e.g. "empty trap" dogs) into the empty traps
            Dim FullTraps(6) As Boolean
            For i As Integer = 0 To 5
                FullTraps(Dogs(i).trap) = True
            Next

            For i As Integer = 0 To 5
                If Dogs(i).trap = TrapNumber.empty Then
                    For j As Integer = 1 To 6
                        If FullTraps(j) = False Then
                            FullTraps(j) = True
                            Dogs(i).trap = j
                            Exit For
                        End If
                    Next
                End If
            Next

            If Dogs(chosendog).trap <> DogTheyBetOnGoesIn Then
                For i As Integer = 0 To 5
                    If Dogs(i).trap = DogTheyBetOnGoesIn Then
                        Dogs(i).trap = Dogs(chosendog).trap
                        Dogs(chosendog).trap = DogTheyBetOnGoesIn
                        Exit For
                    End If
                Next
            End If

        End Sub

        Public Sub New(ByRef values() As String)
            Dim places As String
            With Me
                .DogTheyBetOnGoesIn = values(RaceData.fields.ForceTrap)
                .nDogs = values(RaceData.fields.nDogs)
                .outcometype = values(RaceData.fields.OutcomeType)
                .raceID = values(RaceData.fields.raceid)
                .VideoFileName = values(RaceData.fields.VideoFileName)
                places = values(RaceData.fields.result123) '.Split("--")
                Me.TrueResultPlaces(0) = CInt(places.Substring(0, 1))
                Me.TrueResultPlaces(1) = CInt(places.Substring(1, 1))
                Me.TrueResultPlaces(2) = CInt(places.Substring(2, 1))
                For i As Integer = 0 To 5 : Me.Dogs(i) = New DogInfo : Next
            End With
        End Sub

        Public Sub SaveData(ByVal fs As System.IO.StreamWriter)
            fs.Write( _
                Me.raceID & "," & Me.outcometype & "," & Me.VideoFileName & "," & _
                Me.ChosenDog + 1 & "," & Me.data_rating1 & "," & Me.data_rating2 & "," & Me.data_rating3 & "," & _
                Me.Dogs(Me.ChosenDog).name & "," & Me.data_chosepanel & ",")
            fs.Write("browsetimes:,")
            For Each d As Double In Me.data_browsetimes
                fs.Write(d & ",")
            Next
            fs.Write("tabclicks:,")
            For Each d As Double In Me.data_tabclicks
                fs.Write(d & ",")
            Next
        End Sub
        Public Shared Function dataHeader() As String
            Dim ReturnStr As String = "RaceID,outcome,video,Dogno,rating1,rating2,rating3, dogname,panelchosen,panelbrowestimes"
            For i As Integer = 0 To InfoBrowseForm.panels.count
                ReturnStr &= ", " & InfoBrowseForm.DecodeTabName(i) & "_time"
            Next
            ReturnStr &= ","
            For i As Integer = 0 To InfoBrowseForm.panels.count
                ReturnStr &= ", " & InfoBrowseForm.DecodeTabName(i) & "_clicks"
            Next
            Return ReturnStr
        End Function
    End Class

    Public Class DogInfo
        Public Const fields As Integer = 7
        Public WinPercent As String = 1
        Public avPos As String
        Public RecentForm As String
        Public name As String
        Public County As String
        Public Age As String
        Public trap As TrapNumber

        Public Enum fieldnames As Integer
            winpercent = 1
            avPos
            recentForm
            name
            County
            age
            Trap
        End Enum

        Public Sub New()
            'default constructor for 'blank' dog
            With Me
                .WinPercent = My.Settings.BlankString()
                .avPos = My.Settings.BlankString()
                .RecentForm = My.Settings.BlankString()
                .name = My.Settings.BlankString()
                .County = My.Settings.BlankString()
                .Age = My.Settings.BlankString()
            End With
        End Sub


        Public Sub New(ByVal Values() As String)
            With Me
                .WinPercent = Values(DogInfo.fieldnames.winpercent)
                .avPos = Values(DogInfo.fieldnames.avPos)
                .RecentForm = Values(DogInfo.fieldnames.recentForm)
                .name = Values(DogInfo.fieldnames.name)
                .County = Values(DogInfo.fieldnames.County)
                .Age = Values(DogInfo.fieldnames.age)
                .trap = CInt(Values(DogInfo.fieldnames.Trap))
            End With
        End Sub

    End Class






End Module

