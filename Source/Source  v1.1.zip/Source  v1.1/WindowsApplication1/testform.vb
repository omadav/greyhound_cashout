﻿Public Class testform

   

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Me.OpenFileDialog1.ShowDialog()
        Dim t As TrialSet
        t = New TrialSet(Me.OpenFileDialog1.FileName)

        t.RunTrials()
    End Sub


    Private Sub testform_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class