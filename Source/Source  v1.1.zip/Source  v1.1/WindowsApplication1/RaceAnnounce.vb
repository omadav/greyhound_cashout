﻿Imports System.Windows.Forms

Public Class NextRaceDlg
    Private numraces As String
    Public Sub New(ByVal time As Long, ByVal num As Integer)
        InitializeComponent()
        Me.Timer1.Interval = time
        numraces = num
        Me.OK_Button.Visible = False
    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Me.Timer1.Enabled = False
        Me.OK_Button.Visible = True
    End Sub
    Public Sub announcerace(ByVal num As Integer)
        Me.Trap1.Text = "Race " & num & " of " & numraces
        Me.Timer1.Enabled = True
        Me.ShowDialog()
    End Sub

    Private Sub NextRaceDlg_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Me.Close()
    End Sub
End Class
