﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DrawDlg
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.OK_Button = New System.Windows.Forms.Button
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.PictureBox4 = New System.Windows.Forms.PictureBox
        Me.PictureBox5 = New System.Windows.Forms.PictureBox
        Me.PictureBox6 = New System.Windows.Forms.PictureBox
        Me.Trap6 = New System.Windows.Forms.Label
        Me.Trap5 = New System.Windows.Forms.Label
        Me.Trap3 = New System.Windows.Forms.Label
        Me.Trap2 = New System.Windows.Forms.Label
        Me.PictureBox10 = New System.Windows.Forms.PictureBox
        Me.PictureBox11 = New System.Windows.Forms.PictureBox
        Me.PictureBox12 = New System.Windows.Forms.PictureBox
        Me.Trap4 = New System.Windows.Forms.Label
        Me.Trap1 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.OK_Button.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OK_Button.Location = New System.Drawing.Point(132, 421)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(174, 56)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "RACE!"
        Me.OK_Button.UseVisualStyleBackColor = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 1500
        '
        'PictureBox4
        '
        Me.PictureBox4.BackgroundImage = Global.DogRaceApp.My.Resources.Resources.Trap6
        Me.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox4.InitialImage = Global.DogRaceApp.My.Resources.Resources.Trap1
        Me.PictureBox4.Location = New System.Drawing.Point(378, 361)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(66, 48)
        Me.PictureBox4.TabIndex = 22
        Me.PictureBox4.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackgroundImage = Global.DogRaceApp.My.Resources.Resources.Trap5
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox5.Location = New System.Drawing.Point(378, 305)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(66, 48)
        Me.PictureBox5.TabIndex = 21
        Me.PictureBox5.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.BackgroundImage = Global.DogRaceApp.My.Resources.Resources.Trap4
        Me.PictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox6.Location = New System.Drawing.Point(378, 249)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(66, 48)
        Me.PictureBox6.TabIndex = 20
        Me.PictureBox6.TabStop = False
        '
        'Trap6
        '
        Me.Trap6.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Trap6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Trap6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Trap6.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Trap6.ForeColor = System.Drawing.Color.Gray
        Me.Trap6.Location = New System.Drawing.Point(12, 361)
        Me.Trap6.Name = "Trap6"
        Me.Trap6.Size = New System.Drawing.Size(359, 48)
        Me.Trap6.TabIndex = 19
        Me.Trap6.Text = "Third Dog called Boris"
        Me.Trap6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Trap5
        '
        Me.Trap5.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Trap5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Trap5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Trap5.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Trap5.ForeColor = System.Drawing.Color.Gray
        Me.Trap5.Location = New System.Drawing.Point(12, 305)
        Me.Trap5.Name = "Trap5"
        Me.Trap5.Size = New System.Drawing.Size(359, 48)
        Me.Trap5.TabIndex = 18
        Me.Trap5.Text = "Second Dog with silly name"
        Me.Trap5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Trap3
        '
        Me.Trap3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Trap3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Trap3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Trap3.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Trap3.ForeColor = System.Drawing.Color.Gray
        Me.Trap3.Location = New System.Drawing.Point(12, 193)
        Me.Trap3.Name = "Trap3"
        Me.Trap3.Size = New System.Drawing.Size(359, 48)
        Me.Trap3.TabIndex = 17
        Me.Trap3.Text = "First Dog to Win"
        Me.Trap3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Trap2
        '
        Me.Trap2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Trap2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Trap2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Trap2.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Trap2.ForeColor = System.Drawing.Color.Gray
        Me.Trap2.Location = New System.Drawing.Point(12, 137)
        Me.Trap2.Name = "Trap2"
        Me.Trap2.Size = New System.Drawing.Size(359, 48)
        Me.Trap2.TabIndex = 25
        Me.Trap2.Text = "Third Dog called Boris"
        Me.Trap2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PictureBox10
        '
        Me.PictureBox10.BackgroundImage = Global.DogRaceApp.My.Resources.Resources.Trap3
        Me.PictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox10.InitialImage = Global.DogRaceApp.My.Resources.Resources.Trap1
        Me.PictureBox10.Location = New System.Drawing.Point(378, 193)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(66, 48)
        Me.PictureBox10.TabIndex = 34
        Me.PictureBox10.TabStop = False
        '
        'PictureBox11
        '
        Me.PictureBox11.BackgroundImage = Global.DogRaceApp.My.Resources.Resources.Trap2
        Me.PictureBox11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox11.Location = New System.Drawing.Point(378, 137)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(66, 48)
        Me.PictureBox11.TabIndex = 33
        Me.PictureBox11.TabStop = False
        '
        'PictureBox12
        '
        Me.PictureBox12.BackgroundImage = Global.DogRaceApp.My.Resources.Resources.Trap1
        Me.PictureBox12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox12.Location = New System.Drawing.Point(378, 81)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(66, 48)
        Me.PictureBox12.TabIndex = 32
        Me.PictureBox12.TabStop = False
        '
        'Trap4
        '
        Me.Trap4.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Trap4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Trap4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Trap4.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Trap4.ForeColor = System.Drawing.Color.Gray
        Me.Trap4.Location = New System.Drawing.Point(12, 249)
        Me.Trap4.Name = "Trap4"
        Me.Trap4.Size = New System.Drawing.Size(359, 48)
        Me.Trap4.TabIndex = 31
        Me.Trap4.Text = "Third Dog called Boris"
        Me.Trap4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Trap1
        '
        Me.Trap1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Trap1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Trap1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Trap1.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Trap1.ForeColor = System.Drawing.Color.Gray
        Me.Trap1.Location = New System.Drawing.Point(12, 81)
        Me.Trap1.Name = "Trap1"
        Me.Trap1.Size = New System.Drawing.Size(359, 48)
        Me.Trap1.TabIndex = 30
        Me.Trap1.Text = "Second Dog with silly name"
        Me.Trap1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label7.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(127, 449)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(179, 28)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Traps Drawn"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label7.Visible = False
        '
        'DrawDlg
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.DogRaceApp.My.Resources.Resources.greyhound_3
        Me.ClientSize = New System.Drawing.Size(455, 497)
        Me.ControlBox = False
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.OK_Button)
        Me.Controls.Add(Me.PictureBox10)
        Me.Controls.Add(Me.PictureBox11)
        Me.Controls.Add(Me.PictureBox12)
        Me.Controls.Add(Me.Trap4)
        Me.Controls.Add(Me.Trap1)
        Me.Controls.Add(Me.Trap2)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.Trap6)
        Me.Controls.Add(Me.Trap5)
        Me.Controls.Add(Me.Trap3)
        Me.Controls.Add(Me.Label7)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "DrawDlg"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Trap Draws"
        Me.TopMost = True
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents Trap6 As System.Windows.Forms.Label
    Friend WithEvents Trap5 As System.Windows.Forms.Label
    Friend WithEvents Trap3 As System.Windows.Forms.Label
    Friend WithEvents Trap2 As System.Windows.Forms.Label
    Friend WithEvents PictureBox10 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox11 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox12 As System.Windows.Forms.PictureBox
    Friend WithEvents Trap4 As System.Windows.Forms.Label
    Friend WithEvents Trap1 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label

End Class
